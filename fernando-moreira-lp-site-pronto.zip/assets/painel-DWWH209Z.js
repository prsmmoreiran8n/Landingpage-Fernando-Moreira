import{r as A,j as u,s as us,c as hs,R as ps}from"./site-s9x1GjxH.js";function Ne(o){if(o===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return o}function Li(o,e){o.prototype=Object.create(e.prototype),o.prototype.constructor=o,o.__proto__=e}/*!
 * GSAP 3.15.1
 * https://gsap.com
 *
 * @license Copyright 2008-2026, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
*/var fe={autoSleep:120,force3D:"auto",nullTargetWarn:1,units:{lineHeight:""}},Tt={duration:.5,overwrite:!1,delay:0},Ar,Z,$,ve=1e8,R=1/ve,wr=Math.PI*2,gs=wr/4,fs=0,Bi=Math.sqrt,ms=Math.cos,_s=Math.sin,Q=function(e){return typeof e=="string"},q=function(e){return typeof e=="function"},Ae=function(e){return typeof e=="number"},Rr=function(e){return typeof e=="undefined"},Pe=function(e){return typeof e=="object"},se=function(e){return e!==!1},Er=function(){return typeof window!="undefined"},Bt=function(e){return q(e)||Q(e)},$i=typeof ArrayBuffer=="function"&&ArrayBuffer.isView||function(){},re=Array.isArray,xs=/random\([^)]+\)/g,ws=/,\s*/g,hi=/(?:-?\.?\d|\.)+/gi,Vi=/[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g,st=/[-+=.]*\d+[.e-]*\d*[a-z%]*/g,or=/[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi,Ii=/[+-]=-?[.\d]+/,vs=/[^,'"\[\]\s]+/gi,bs=/^[+\-=e\s\d]*\d+[.\d]*([a-z]*|%)\s*$/i,I,Se,vr,Fr,me={},Wt={},Ui,qi=function(e){return(Wt=dt(e,me))&&ce},Lr=function(e,t){return console.warn("Invalid property",e,"set to",t,"Missing plugin? gsap.registerPlugin()")},jt=function(e,t){return!t&&console.warn(e)},Wi=function(e,t){return e&&(me[e]=t)&&Wt&&(Wt[e]=t)||me},Ct=function(){return 0},ys={suppressEvents:!0,isStart:!0,kill:!1},It={suppressEvents:!0,kill:!1},ks={suppressEvents:!0},Br={},Ve=[],br={},Yi,ue={},lr={},pi=30,Ut=[],$r="",Vr=function(e){var t=e[0],r,i;if(Pe(t)||q(t)||(e=[e]),!(r=(t._gsap||{}).harness)){for(i=Ut.length;i--&&!Ut[i].targetTest(t););r=Ut[i]}for(i=e.length;i--;)e[i]&&(e[i]._gsap||(e[i]._gsap=new fn(e[i],r)))||e.splice(i,1);return e},Je=function(e){return e._gsap||Vr(be(e))[0]._gsap},Xi=function(e,t,r){return(r=e[t])&&q(r)?e[t]():Rr(r)&&e.getAttribute&&e.getAttribute(t)||r},ae=function(e,t){return(e=e.split(",")).forEach(t)||e},Y=function(e){return Math.round(e*1e5)/1e5||0},V=function(e){return Math.round(e*1e7)/1e7||0},ot=function(e,t){var r=t.charAt(0),i=parseFloat(t.substr(2));return e=parseFloat(e),r==="+"?e+i:r==="-"?e-i:r==="*"?e*i:e/i},Ts=function(e,t){for(var r=t.length,i=0;e.indexOf(t[i])<0&&++i<r;);return i<r},Yt=function(){var e=Ve.length,t=Ve.slice(0),r,i;for(br={},Ve.length=0,r=0;r<e;r++)i=t[r],i&&i._lazy&&(i.render(i._lazy[0],i._lazy[1],!0)._lazy=0)},Ir=function(e){return!!(e._initted||e._startAt||e.add)},Hi=function(e,t,r,i){Ve.length&&!Z&&Yt(),e.render(t,r,!!(Z&&t<0&&Ir(e))),Ve.length&&!Z&&Yt()},Gi=function(e){var t=parseFloat(e);return(t||t===0)&&(e+"").match(vs).length<2?t:Q(e)?e.trim():e},Ki=function(e){return e},_e=function(e,t){for(var r in t)r in e||(e[r]=t[r]);return e},js=function(e){return function(t,r){for(var i in r)i in t||i==="duration"&&e||i==="ease"||(t[i]=r[i])}},dt=function(e,t){for(var r in t)e[r]=t[r];return e},gi=function o(e,t){for(var r in t)r!=="__proto__"&&r!=="constructor"&&r!=="prototype"&&(e[r]=Pe(t[r])?o(e[r]||(e[r]={}),t[r]):t[r]);return e},Xt=function(e,t){var r={},i;for(i in e)i in t||(r[i]=e[i]);return r},bt=function(e){var t=e.parent||I,r=e.keyframes?js(re(e.keyframes)):_e;if(se(e.inherit))for(;t;)r(e,t.vars.defaults),t=t.parent||t._dp;return e},Cs=function(e,t){for(var r=e.length,i=r===t.length;i&&r--&&e[r]===t[r];);return r<0},Qi=function(e,t,r,i,n){var s=e[i],a;if(n)for(a=t[n];s&&s[n]>a;)s=s._prev;return s?(t._next=s._next,s._next=t):(t._next=e[r],e[r]=t),t._next?t._next._prev=t:e[i]=t,t._prev=s,t.parent=t._dp=e,t},er=function(e,t,r,i){r===void 0&&(r="_first"),i===void 0&&(i="_last");var n=t._prev,s=t._next;n?n._next=s:e[r]===t&&(e[r]=s),s?s._prev=n:e[i]===t&&(e[i]=n),t._next=t._prev=t.parent=null},Ue=function(e,t){e.parent&&(!t||e.parent.autoRemoveChildren)&&e.parent.remove&&e.parent.remove(e),e._act=0},et=function(e,t){if(e&&(!t||t._end>e._dur||t._start<0))for(var r=e;r;)r._dirty=1,r=r.parent;return e},zs=function(e){for(var t=e.parent;t&&t.parent;)t._dirty=1,t.totalDuration(),t=t.parent;return e},yr=function(e,t,r,i){return e._startAt&&(Z?e._startAt.revert(It):e.vars.immediateRender&&!e.vars.autoRevert||e._startAt.render(t,!0,i))},Ss=function o(e){return!e||e._ts&&o(e.parent)},fi=function(e){return e._repeat?ut(e._tTime,e=e.duration()+e._rDelay)*e:0},ut=function(e,t){var r=Math.floor(e=V(e/t));return e&&r===e?r-1:r},Ht=function(e,t){return(e-t._start)*t._ts+(t._ts>=0?0:t._dirty?t.totalDuration():t._tDur)},tr=function(e){return e._end=V(e._start+(e._tDur/Math.abs(e._ts||e._rts||R)||0))},rr=function(e,t){var r=e._dp;return r&&r.smoothChildTiming&&e._ts&&(e._start=V(r._time-(e._ts>0?t/e._ts:((e._dirty?e.totalDuration():e._tDur)-t)/-e._ts)),tr(e),r._dirty||et(r,e)),e},Zi=function(e,t){var r;if((t._time||!t._dur&&t._initted||t._start<e._time&&(t._dur||!t.add))&&(r=Ht(e.rawTime(),t),(!t._dur||At(0,t.totalDuration(),r)-t._tTime>R)&&t.render(r,!0)),et(e,t)._dp&&e._initted&&e._time>=e._dur&&e._ts){if(e._dur<e.duration())for(r=e;r._dp;)r.rawTime()>=0&&r.totalTime(r._tTime),r=r._dp;e._zTime=-R}},Me=function(e,t,r,i){return t.parent&&Ue(t),t._start=V((Ae(r)?r:!r&&Gt(t)&&(!e._last||e._last._start>=e._time)?e._last?e._last._start:e._time:r||e!==I?we(e,r,t):e._time)+t._delay),t._end=V(t._start+(t.totalDuration()/Math.abs(t.timeScale())||0)),Qi(e,t,"_first","_last",e._sort?"_start":0),Gt(t)||(e._recent=t),i||Zi(e,t),e._ts<0&&rr(e,e._tTime),e},Ji=function(e,t){return(me.ScrollTrigger||Lr("scrollTrigger",t))&&me.ScrollTrigger.create(t,e)},en=function(e,t,r,i,n){if(qr(e,t,n),!e._initted)return 1;if(!r&&e._pt&&!Z&&(e._dur&&e.vars.lazy!==!1||!e._dur&&e.vars.lazy)&&Yi!==he.frame)return Ve.push(e),e._lazy=[n,i],1},Ms=function o(e){var t=e.parent;return t&&t._ts&&t._initted&&!t._lock&&(t.rawTime()<0||o(t))},Gt=function(e){var t=e.data;return t==="isFromStart"||t==="isStart"},Os=function(e,t,r,i){var n=e.ratio,s=t<0||!t&&(!e._start&&Ms(e)&&!(!e._initted&&Gt(e))||(e._ts<0||e._dp._ts<0)&&!Gt(e))?0:1,a=e._rDelay,l=0,c,d,p;if(a&&e._repeat&&(l=At(0,e._tDur,t),d=ut(l,a),e._yoyo&&d&1&&(s=1-s),d!==ut(e._tTime,a)&&(n=1-s,e.vars.repeatRefresh&&e._initted&&e.invalidate())),s!==n||Z||i||e._zTime===R||!t&&e._zTime){if(!e._initted&&en(e,t,i,r,l))return;for(p=e._zTime,e._zTime=t||(r?R:0),r||(r=t&&!p),e.ratio=s,e._from&&(s=1-s),e._time=0,e._tTime=l,c=e._pt;c;)c.r(s,c.d),c=c._next;t<0&&yr(e,t,r,!0),e._onUpdate&&!r&&pe(e,"onUpdate"),l&&e._repeat&&!r&&e.parent&&pe(e,"onRepeat"),(t>=e._tDur||t<0)&&e.ratio===s&&(s&&Ue(e,1),!r&&!Z&&(pe(e,s?"onComplete":"onReverseComplete",!0),e._prom&&e._prom()))}else e._zTime||(e._zTime=t)},Ps=function(e,t,r){var i;if(r>t)for(i=e._first;i&&i._start<=r;){if(i.data==="isPause"&&i._start>t)return i;i=i._next}else for(i=e._last;i&&i._start>=r;){if(i.data==="isPause"&&i._start<t)return i;i=i._prev}},ht=function(e,t,r,i){var n=e._repeat,s=V(t)||0,a=e._tTime/e._tDur;return a&&!i&&(e._time*=s/e._dur),e._dur=s,e._tDur=n?n<0?1e10:V(s*(n+1)+e._rDelay*n):s,a>0&&!i&&rr(e,e._tTime=e._tDur*a),e.parent&&tr(e),r||et(e.parent,e),e},mi=function(e){return e instanceof ne?et(e):ht(e,e._dur)},Ns={_start:0,endTime:Ct,totalDuration:Ct},we=function o(e,t,r){var i=e.labels,n=e._recent||Ns,s=e.duration()>=ve?n.endTime(!1):e._dur,a,l,c;return Q(t)&&(isNaN(t)||t in i)?(l=t.charAt(0),c=t.substr(-1)==="%",a=t.indexOf("="),l==="<"||l===">"?(a>=0&&(t=t.replace(/=/,"")),(l==="<"?n._start:n.endTime(n._repeat>=0))+(parseFloat(t.substr(1))||0)*(c?(a<0?n:r).totalDuration()/100:1)):a<0?(t in i||(i[t]=s),i[t]):(l=parseFloat(t.charAt(a-1)+t.substr(a+1)),c&&r&&(l=l/100*(re(r)?r[0]:r).totalDuration()),a>1?o(e,t.substr(0,a-1),r)+l:s+l)):t==null?s:+t},yt=function(e,t,r){var i=Ae(t[1]),n=(i?2:1)+(e<2?0:1),s=t[n],a,l;if(i&&(s.duration=t[1]),s.parent=r,e){for(a=s,l=r;l&&!("immediateRender"in a);)a=l.vars.defaults||{},l=se(l.vars.inherit)&&l.parent;s.immediateRender=se(a.immediateRender),e<2?s.runBackwards=1:s.startAt=t[n-1]}return new G(t[0],s,t[n+1])},Ye=function(e,t){return e||e===0?t(e):t},At=function(e,t,r){return r<e?e:r>t?t:r},te=function(e,t){return!Q(e)||!(t=bs.exec(e))?"":t[1]},Ds=function(e,t,r){return Ye(r,function(i){return At(e,t,i)})},kr=[].slice,tn=function(e,t){return e&&Pe(e)&&"length"in e&&(!t&&!e.length||e.length-1 in e&&Pe(e[0]))&&!e.nodeType&&e!==Se},As=function(e,t,r){return r===void 0&&(r=[]),e.forEach(function(i){var n;return Q(i)&&!t||tn(i,1)?(n=r).push.apply(n,be(i)):r.push(i)})||r},be=function(e,t,r){return $&&!t&&$.selector?$.selector(e):Q(e)&&!r&&(vr||!pt())?kr.call((t||Fr).querySelectorAll(e),0):re(e)?As(e,r):tn(e)?kr.call(e,0):e?[e]:[]},Tr=function(e){return e=be(e)[0]||jt("Invalid scope")||{},function(t){var r=e.current||e.nativeElement||e;return be(t,r.querySelectorAll?r:r===e?jt("Invalid scope")||Fr.createElement("div"):e)}},rn=function(e){return e.sort(function(){return .5-Math.random()})},nn=function(e){if(q(e))return e;var t=Pe(e)?e:{each:e},r=tt(t.ease),i=t.from||0,n=parseFloat(t.base)||0,s={},a=i>0&&i<1,l=isNaN(i)||a,c=t.axis,d=i,p=i;return Q(i)?d=p={center:.5,edges:.5,end:1}[i]||0:!a&&l&&(d=i[0],p=i[1]),function(g,f,m){var h=(m||t).length,_=s[h],v,b,y,k,w,S,T,j,C;if(!_){if(C=t.grid==="auto"?0:(t.grid||[1,ve])[1],!C){for(T=-ve;T<(T=m[C++].getBoundingClientRect().left)&&C<h;);C<h&&C--}for(_=s[h]=[],v=l?Math.min(C,h)*d-.5:i%C,b=C===ve?0:l?h*p/C-.5:i/C|0,T=0,j=ve,S=0;S<h;S++)y=S%C-v,k=b-(S/C|0),_[S]=w=c?Math.abs(c==="y"?k:y):Bi(y*y+k*k),w>T&&(T=w),w<j&&(j=w);i==="random"&&rn(_),_.max=T-j,_.min=j,_.v=h=(parseFloat(t.amount)||parseFloat(t.each)*(C>h?h-1:c?c==="y"?h/C:C:Math.max(C,h/C))||0)*(i==="edges"?-1:1),_.b=h<0?n-h:n,_.u=te(t.amount||t.each)||0,r=r&&h<0?Xs(r):r}return h=(_[g]-_.min)/_.max||0,V(_.b+(r?r(h):h)*_.v)+_.u}},jr=function(e){var t=Math.pow(10,((e+"").split(".")[1]||"").length);return function(r){var i=V(Math.round(parseFloat(r)/e)*e*t);return(i-i%1)/t+(Ae(r)?0:te(r))}},sn=function(e,t){var r=re(e),i,n;return!r&&Pe(e)&&(i=r=e.radius||ve,e.values?(e=be(e.values),(n=!Ae(e[0]))&&(i*=i)):e=jr(e.increment)),Ye(t,r?q(e)?function(s){return n=e(s),Math.abs(n-s)<=i?n:s}:function(s){for(var a=parseFloat(n?s.x:s),l=parseFloat(n?s.y:0),c=ve,d=0,p=e.length,g,f;p--;)n?(g=e[p].x-a,f=e[p].y-l,g=g*g+f*f):g=Math.abs(e[p]-a),g<c&&(c=g,d=p);return d=!i||c<=i?e[d]:s,n||d===s||Ae(s)?d:d+te(s)}:jr(e))},an=function(e,t,r,i){return Ye(re(e)?!t:r===!0?!!(r=0):!i,function(){return re(e)?e[~~(Math.random()*e.length)]:(r=r||1e-5)&&(i=r<1?Math.pow(10,(r+"").length-2):1)&&Math.floor(Math.round((e-r/2+Math.random()*(t-e+r*.99))/r)*r*i)/i})},Rs=function(){for(var e=arguments.length,t=new Array(e),r=0;r<e;r++)t[r]=arguments[r];return function(i){return t.reduce(function(n,s){return s(n)},i)}},Es=function(e,t){return function(r){return e(parseFloat(r))+(t||te(r))}},Fs=function(e,t,r){return ln(e,t,0,1,r)},on=function(e,t,r){return Ye(r,function(i){return e[~~t(i)]})},Ls=function o(e,t,r){var i=t-e;return re(e)?on(e,o(0,e.length),t):Ye(r,function(n){return(i+(n-e)%i)%i+e})},Bs=function o(e,t,r){var i=t-e,n=i*2;return re(e)?on(e,o(0,e.length-1),t):Ye(r,function(s){return s=(n+(s-e)%n)%n||0,e+(s>i?n-s:s)})},zt=function(e){return e.replace(xs,function(t){var r=t.indexOf("[")+1,i=t.substring(r||7,r?t.indexOf("]"):t.length-1).split(ws);return an(r?i:+i[0],r?0:+i[1],+i[2]||1e-5)})},ln=function(e,t,r,i,n){var s=t-e,a=i-r;return Ye(n,function(l){return r+((l-e)/s*a||0)})},$s=function o(e,t,r,i){var n=isNaN(e+t)?0:function(f){return(1-f)*e+f*t};if(!n){var s=Q(e),a={},l,c,d,p,g;if(r===!0&&(i=1)&&(r=null),s)e={p:e},t={p:t};else if(re(e)&&!re(t)){for(d=[],p=e.length,g=p-2,c=1;c<p;c++)d.push(o(e[c-1],e[c]));p--,n=function(m){m*=p;var h=Math.min(g,~~m);return d[h](m-h)},r=t}else i||(e=dt(re(e)?[]:{},e));if(!d){for(l in t)Ur.call(a,e,l,"get",t[l]);n=function(m){return Xr(m,a)||(s?e.p:e)}}}return Ye(r,n)},_i=function(e,t,r){var i=e.labels,n=ve,s,a,l;for(s in i)a=i[s]-t,a<0==!!r&&a&&n>(a=Math.abs(a))&&(l=s,n=a);return l},pe=function(e,t,r){var i=e.vars,n=i[t],s=$,a=e._ctx,l,c,d;if(n)return l=i[t+"Params"],c=i.callbackScope||e,r&&Ve.length&&Yt(),a&&($=a),d=l?n.apply(c,l):n.call(c),$=s,d},xt=function(e){return Ue(e),e.scrollTrigger&&e.scrollTrigger.kill(!!Z),e.progress()<1&&pe(e,"onInterrupt"),e},at,cn=[],dn=function(e){if(e)if(e=!e.name&&e.default||e,Er()||e.headless){var t=e.name,r=q(e),i=t&&!r&&e.init?function(){this._props=[]}:e,n={init:Ct,render:Xr,add:Ur,kill:ia,modifier:ra,rawVars:0},s={targetTest:0,get:0,getSetter:Yr,aliases:{},register:0};if(pt(),e!==i){if(ue[t])return;_e(i,_e(Xt(e,n),s)),dt(i.prototype,dt(n,Xt(e,s))),ue[i.prop=t]=i,e.targetTest&&(Ut.push(i),Br[t]=1),t=(t==="css"?"CSS":t.charAt(0).toUpperCase()+t.substr(1))+"Plugin"}Wi(t,i),e.register&&e.register(ce,i,oe)}else cn.push(e)},F=255,wt={aqua:[0,F,F],lime:[0,F,0],silver:[192,192,192],black:[0,0,0],maroon:[128,0,0],teal:[0,128,128],blue:[0,0,F],navy:[0,0,128],white:[F,F,F],olive:[128,128,0],yellow:[F,F,0],orange:[F,165,0],gray:[128,128,128],purple:[128,0,128],green:[0,128,0],red:[F,0,0],pink:[F,192,203],cyan:[0,F,F],transparent:[F,F,F,0]},cr=function(e,t,r){return e+=e<0?1:e>1?-1:0,(e*6<1?t+(r-t)*e*6:e<.5?r:e*3<2?t+(r-t)*(2/3-e)*6:t)*F+.5|0},un=function(e,t,r){var i=e?Ae(e)?[e>>16,e>>8&F,e&F]:0:wt.black,n,s,a,l,c,d,p,g,f,m;if(!i){if(e.substr(-1)===","&&(e=e.substr(0,e.length-1)),wt[e])i=wt[e];else if(e.charAt(0)==="#"){if(e.length<6&&(n=e.charAt(1),s=e.charAt(2),a=e.charAt(3),e="#"+n+n+s+s+a+a+(e.length===5?e.charAt(4)+e.charAt(4):"")),e.length===9)return i=parseInt(e.substr(1,6),16),[i>>16,i>>8&F,i&F,parseInt(e.substr(7),16)/255];e=parseInt(e.substr(1),16),i=[e>>16,e>>8&F,e&F]}else if(e.substr(0,3)==="hsl"){if(i=m=e.match(hi),!t)l=+i[0]%360/360,c=+i[1]/100,d=+i[2]/100,s=d<=.5?d*(c+1):d+c-d*c,n=d*2-s,i.length>3&&(i[3]*=1),i[0]=cr(l+1/3,n,s),i[1]=cr(l,n,s),i[2]=cr(l-1/3,n,s);else if(~e.indexOf("="))return i=e.match(Vi),r&&i.length<4&&(i[3]=1),i}else i=e.match(hi)||wt.transparent;i=i.map(Number)}return t&&!m&&(n=i[0]/F,s=i[1]/F,a=i[2]/F,p=Math.max(n,s,a),g=Math.min(n,s,a),d=(p+g)/2,p===g?l=c=0:(f=p-g,c=d>.5?f/(2-p-g):f/(p+g),l=p===n?(s-a)/f+(s<a?6:0):p===s?(a-n)/f+2:(n-s)/f+4,l*=60),i[0]=~~(l+.5),i[1]=~~(c*100+.5),i[2]=~~(d*100+.5)),r&&i.length<4&&(i[3]=1),i},hn=function(e){var t=[],r=[],i=-1;return e.split(Ie).forEach(function(n){var s=n.match(st)||[];t.push.apply(t,s),r.push(i+=s.length+1)}),t.c=r,t},xi=function(e,t,r){var i="",n=(e+i).match(Ie),s=t?"hsla(":"rgba(",a=0,l,c,d,p;if(!n)return e;if(n=n.map(function(g){return(g=un(g,t,1))&&s+(t?g[0]+","+g[1]+"%,"+g[2]+"%,"+g[3]:g.join(","))+")"}),r&&(d=hn(e),l=r.c,l.join(i)!==d.c.join(i)))for(c=e.replace(Ie,"1").split(st),p=c.length-1;a<p;a++)i+=c[a]+(~l.indexOf(a)?n.shift()||s+"0,0,0,0)":(d.length?d:n.length?n:r).shift());if(!c)for(c=e.split(Ie),p=c.length-1;a<p;a++)i+=c[a]+n[a];return i+c[p]},Ie=function(){var o="(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b",e;for(e in wt)o+="|"+e+"\\b";return new RegExp(o+")","gi")}(),Vs=/hsl[a]?\(/,pn=function(e){var t=e.join(" "),r;if(Ie.lastIndex=0,Ie.test(t))return r=Vs.test(t),e[1]=xi(e[1],r),e[0]=xi(e[0],r,hn(e[1])),!0},St,he=function(){var o=Date.now,e=500,t=33,r=o(),i=r,n=1e3/240,s=n,a=[],l,c,d,p,g,f,m=function h(_){var v=o()-i,b=_===!0,y,k,w,S;if((v>e||v<0)&&(r+=v-t),i+=v,w=i-r,y=w-s,(y>0||b)&&(S=++p.frame,g=w-p.time*1e3,p.time=w=w/1e3,s+=y+(y>=n?0:n-y),k=1),b||(l=c(h)),k)for(f=0;f<a.length;f++)a[f](w,g,S,_)};return p={time:0,frame:0,tick:function(){m(!0)},deltaRatio:function(_){return g/(1e3/(_||60))},wake:function(){Ui&&(!vr&&Er()&&(Se=vr=window,Fr=Se.document||{},me.gsap=ce,(Se.gsapVersions||(Se.gsapVersions=[])).push(ce.version),qi(Wt||Se.GreenSockGlobals||!Se.gsap&&Se||{}),cn.forEach(dn)),d=typeof requestAnimationFrame!="undefined"&&requestAnimationFrame,l&&p.sleep(),c=d||function(_){return setTimeout(_,s-p.time*1e3+1|0)},St=1,m(2))},sleep:function(){(d?cancelAnimationFrame:clearTimeout)(l),St=0,c=Ct},lagSmoothing:function(_,v){e=_||1/0,t=Math.min(v||33,e)},fps:function(_){n=1e3/(_||240),s=p.time*1e3+n},add:function(_,v,b){var y=v?function(k,w,S,T){_(k,w,S,T),p.remove(y)}:_;return p.remove(_),a[b?"unshift":"push"](y),pt(),y},remove:function(_,v){~(v=a.indexOf(_))&&a.splice(v,1)&&f>=v&&f--},_listeners:a},p}(),pt=function(){return!St&&he.wake()},N={},Is=/^[\d.\-M][\d.\-,\s]/,Us=/["']/g,qs=function(e){for(var t={},r=e.substr(1,e.length-3).split(":"),i=r[0],n=1,s=r.length,a,l,c;n<s;n++)l=r[n],a=n!==s-1?l.lastIndexOf(","):l.length,c=l.substr(0,a),t[i]=isNaN(c)?c.replace(Us,"").trim():+c,i=l.substr(a+1).trim();return t},Ws=function(e){var t=e.indexOf("(")+1,r=e.indexOf(")"),i=e.indexOf("(",t);return e.substring(t,~i&&i<r?e.indexOf(")",r+1):r)},Ys=function(e){var t=(e+"").split("("),r=N[t[0]];return r&&t.length>1&&r.config?r.config.apply(null,~e.indexOf("{")?[qs(t[1])]:Ws(e).split(",").map(Gi)):N._CE&&Is.test(e)?N._CE("",e):r},Xs=function(e){return function(t){return 1-e(1-t)}},tt=function(e,t){return e&&(q(e)?e:N[e]||Ys(e))||t},it=function(e,t,r,i){r===void 0&&(r=function(l){return 1-t(1-l)}),i===void 0&&(i=function(l){return l<.5?t(l*2)/2:1-t((1-l)*2)/2});var n={easeIn:t,easeOut:r,easeInOut:i},s;return ae(e,function(a){N[a]=me[a]=n,N[s=a.toLowerCase()]=r;for(var l in n)N[s+(l==="easeIn"?".in":l==="easeOut"?".out":".inOut")]=N[a+"."+l]=n[l]}),n},gn=function(e){return function(t){return t<.5?(1-e(1-t*2))/2:.5+e((t-.5)*2)/2}},dr=function o(e,t,r){var i=t>=1?t:1,n=(r||(e?.3:.45))/(t<1?t:1),s=n/wr*(Math.asin(1/i)||0),a=function(d){return d===1?1:i*Math.pow(2,-10*d)*_s((d-s)*n)+1},l=e==="out"?a:e==="in"?function(c){return 1-a(1-c)}:gn(a);return n=wr/n,l.config=function(c,d){return o(e,c,d)},l},ur=function o(e,t){t===void 0&&(t=1.70158);var r=function(s){return s?--s*s*((t+1)*s+t)+1:0},i=e==="out"?r:e==="in"?function(n){return 1-r(1-n)}:gn(r);return i.config=function(n){return o(e,n)},i};ae("Linear,Quad,Cubic,Quart,Quint,Strong",function(o,e){var t=e<5?e+1:e;it(o+",Power"+(t-1),e?function(r){return Math.pow(r,t)}:function(r){return r},function(r){return 1-Math.pow(1-r,t)},function(r){return r<.5?Math.pow(r*2,t)/2:1-Math.pow((1-r)*2,t)/2})});N.Linear.easeNone=N.none=N.Linear.easeIn;it("Elastic",dr("in"),dr("out"),dr());(function(o,e){var t=1/e,r=2*t,i=2.5*t,n=function(a){return a<t?o*a*a:a<r?o*Math.pow(a-1.5/e,2)+.75:a<i?o*(a-=2.25/e)*a+.9375:o*Math.pow(a-2.625/e,2)+.984375};it("Bounce",function(s){return 1-n(1-s)},n)})(7.5625,2.75);it("Expo",function(o){return Math.pow(2,10*(o-1))*o+o*o*o*o*o*o*(1-o)});it("Circ",function(o){return-(Bi(1-o*o)-1)});it("Sine",function(o){return o===1?1:-ms(o*gs)+1});it("Back",ur("in"),ur("out"),ur());N.SteppedEase=N.steps=me.SteppedEase={config:function(e,t){e===void 0&&(e=1);var r=1/e,i=e+(t?0:1),n=t?1:0,s=1-R;return function(a){return((i*At(0,s,a)|0)+n)*r}}};Tt.ease=N["quad.out"];ae("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt",function(o){return $r+=o+","+o+"Params,"});var fn=function(e,t){this.id=fs++,e._gsap=this,this.target=e,this.harness=t,this.get=t?t.get:Xi,this.set=t?t.getSetter:Yr},Mt=function(){function o(t){this.vars=t,this._delay=+t.delay||0,(this._repeat=t.repeat===1/0?-2:t.repeat||0)&&(this._rDelay=t.repeatDelay||0,this._yoyo=!!t.yoyo||!!t.yoyoEase),this._ts=1,ht(this,+t.duration,1,1),this.data=t.data,$&&(this._ctx=$,$.data.push(this)),St||he.wake()}var e=o.prototype;return e.delay=function(r){return r||r===0?(this.parent&&this.parent.smoothChildTiming&&this.startTime(this._start+r-this._delay),this._delay=r,this):this._delay},e.duration=function(r){return arguments.length?this.totalDuration(this._repeat>0?r+(r+this._rDelay)*this._repeat:r):this.totalDuration()&&this._dur},e.totalDuration=function(r){return arguments.length?(this._dirty=0,ht(this,this._repeat<0?r:(r-this._repeat*this._rDelay)/(this._repeat+1))):this._tDur},e.totalTime=function(r,i){if(pt(),!arguments.length)return this._tTime;var n=this._dp;if(n&&n.smoothChildTiming&&this._ts){for(rr(this,r),!n._dp||n.parent||Zi(n,this);n&&n.parent;)n.parent._time!==n._start+(n._ts>=0?n._tTime/n._ts:(n.totalDuration()-n._tTime)/-n._ts)&&n.totalTime(n._tTime,!0),n=n.parent;!this.parent&&this._dp.autoRemoveChildren&&(this._ts>0&&r<this._tDur||this._ts<0&&r>0||!this._tDur&&!r)&&Me(this._dp,this,this._start-this._delay)}return(this._tTime!==r||!this._dur&&!i||this._initted&&Math.abs(this._zTime)===R||!this._initted&&this._dur&&r||!r&&!this._initted&&(this.add||this._ptLookup))&&(this._ts||(this._pTime=r),Hi(this,r,i)),this},e.time=function(r,i){return arguments.length?this.totalTime(Math.min(this.totalDuration(),r+fi(this))%(this._dur+this._rDelay)||(r?this._dur:0),i):this._time},e.totalProgress=function(r,i){return arguments.length?this.totalTime(this.totalDuration()*r,i):this.totalDuration()?Math.min(1,this._tTime/this._tDur):this.rawTime()>=0&&this._initted?1:0},e.progress=function(r,i){return arguments.length?this.totalTime(this.duration()*(this._yoyo&&!(this.iteration()&1)?1-r:r)+fi(this),i):this.duration()?Math.min(1,this._time/this._dur):this.rawTime()>0?1:0},e.iteration=function(r,i){var n=this.duration()+this._rDelay;return arguments.length?this.totalTime(this._time+(r-1)*n,i):this._repeat?ut(this._tTime,n)+1:1},e.timeScale=function(r,i){if(!arguments.length)return this._rts===-R?0:this._rts;if(this._rts===r)return this;var n=this.parent&&this._ts?Ht(this.parent._time,this):this._tTime,s=this._rts<0;this._rts=+r||0,this._ts=this._ps||r===-R?0:this._rts;var a=this.totalDuration();return(s!==this._rts<0||n>0&&n<a)&&this.totalTime(At(-Math.abs(this._delay),a,n),i!==!1),tr(this),zs(this)},e.paused=function(r){if(!arguments.length)return this._ps;if(this._ps!==r)if(this._ps=r,r)this._pTime=this._tTime||Math.max(-this._delay,this.rawTime()),this._ts=this._act=0;else{pt(),this._ts=this._rts;var i=this.parent&&!this.parent.smoothChildTiming?this.rawTime():this._tTime||this._pTime,n=this.progress()===1&&Math.abs(this._zTime)!==R,s;if(n)for(this._tTime-=R,s=this._first;s;){if(!s._dur&&s._zTime<0&&s._ts&&s._start<=i+R){n=!1;break}s=s._next}this.totalTime(i,n)}return this},e.startTime=function(r){if(arguments.length){this._start=V(r);var i=this.parent||this._dp;return i&&(i._sort||!this.parent)&&Me(i,this,this._start-this._delay),this}return this._start},e.endTime=function(r){return this._start+(se(r)?this.totalDuration():this.duration())/Math.abs(this._ts||1)},e.rawTime=function(r){var i=this.parent||this._dp;return i?r&&(!this._ts||this._repeat&&this._time&&this.totalProgress()<1)?this._tTime%(this._dur+this._rDelay):this._ts?Ht(i.rawTime(r),this):this._tTime:this._tTime},e.revert=function(r){r===void 0&&(r=ks);var i=Z;return Z=r,Ir(this)&&(this.timeline&&this.timeline.revert(r),this.totalTime(-.01,r.suppressEvents)),this.data!=="nested"&&r.kill!==!1&&this.kill(),Z=i,this},e.globalTime=function(r){for(var i=this,n=arguments.length?r:i.rawTime();i;)n=i._start+n/(Math.abs(i._ts)||1),i=i._dp;return!this.parent&&this._sat?this._sat.globalTime(r):n},e.repeat=function(r){return arguments.length?(this._repeat=r===1/0?-2:r,mi(this)):this._repeat===-2?1/0:this._repeat},e.repeatDelay=function(r){if(arguments.length){var i=this._time;return this._rDelay=r,mi(this),i?this.time(i):this}return this._rDelay},e.yoyo=function(r){return arguments.length?(this._yoyo=r,this):this._yoyo},e.seek=function(r,i){return this.totalTime(we(this,r),se(i))},e.restart=function(r,i){return this.play().totalTime(r?-this._delay:0,se(i)),this._dur||(this._zTime=-R),this},e.play=function(r,i){return r!=null&&this.seek(r,i),this.reversed(!1).paused(!1)},e.reverse=function(r,i){return r!=null&&this.seek(r||this.totalDuration(),i),this.reversed(!0).paused(!1)},e.pause=function(r,i){return r!=null&&this.seek(r,i),this.paused(!0)},e.resume=function(){return this.paused(!1)},e.reversed=function(r){return arguments.length?(!!r!==this.reversed()&&this.timeScale(-this._rts||(r?-R:0)),this):this._rts<0},e.invalidate=function(){return this._initted=this._act=0,this._zTime=-R,this},e.isActive=function(){var r=this.parent||this._dp,i=this._start,n;return!!(!r||this._ts&&this._initted&&r.isActive()&&(n=r.rawTime(!0))>=i&&n<this.endTime(!0)-R)},e.eventCallback=function(r,i,n){var s=this.vars;return arguments.length>1?(i?(s[r]=i,n&&(s[r+"Params"]=n),r==="onUpdate"&&(this._onUpdate=i)):delete s[r],this):s[r]},e.then=function(r){var i=this,n=i._prom;return new Promise(function(s){var a=q(r)?r:Ki,l=function(){var d=i.then;i.then=null,n&&n(),q(a)&&(a=a(i))&&(a.then||a===i)&&(i.then=d),s(a),i.then=d};i._initted&&i.totalProgress()===1&&i._ts>=0||!i._tTime&&i._ts<0?l():i._prom=l})},e.kill=function(){xt(this)},o}();_e(Mt.prototype,{_time:0,_start:0,_end:0,_tTime:0,_tDur:0,_dirty:0,_repeat:0,_yoyo:!1,parent:null,_initted:!1,_rDelay:0,_ts:1,_dp:0,ratio:0,_zTime:-R,_prom:0,_ps:!1,_rts:1});var ne=function(o){Li(e,o);function e(r,i){var n;return r===void 0&&(r={}),n=o.call(this,r)||this,n.labels={},n.smoothChildTiming=!!r.smoothChildTiming,n.autoRemoveChildren=!!r.autoRemoveChildren,n._sort=se(r.sortChildren),I&&Me(r.parent||I,Ne(n),i),r.reversed&&n.reverse(),r.paused&&n.paused(!0),r.scrollTrigger&&Ji(Ne(n),r.scrollTrigger),n}var t=e.prototype;return t.to=function(i,n,s){return yt(0,arguments,this),this},t.from=function(i,n,s){return yt(1,arguments,this),this},t.fromTo=function(i,n,s,a){return yt(2,arguments,this),this},t.set=function(i,n,s){return n.duration=0,n.parent=this,bt(n).repeatDelay||(n.repeat=0),n.immediateRender=!!n.immediateRender,new G(i,n,we(this,s),1),this},t.call=function(i,n,s){return Me(this,G.delayedCall(0,i,n),s)},t.staggerTo=function(i,n,s,a,l,c,d){return s.duration=n,s.stagger=s.stagger||a,s.onComplete=c,s.onCompleteParams=d,s.parent=this,new G(i,s,we(this,l)),this},t.staggerFrom=function(i,n,s,a,l,c,d){return s.runBackwards=1,bt(s).immediateRender=se(s.immediateRender),this.staggerTo(i,n,s,a,l,c,d)},t.staggerFromTo=function(i,n,s,a,l,c,d,p){return a.startAt=s,bt(a).immediateRender=se(a.immediateRender),this.staggerTo(i,n,a,l,c,d,p)},t.render=function(i,n,s){var a=this._time,l=this._dirty?this.totalDuration():this._tDur,c=this._dur,d=i<=0?0:V(i),p=this._zTime<0!=i<0&&(this._initted||!c),g,f,m,h,_,v,b,y,k,w,S,T;if(this!==I&&d>l&&i>=0&&(d=l),d!==this._tTime||s||p){if(a!==this._time&&c&&(d+=this._time-a,i+=this._time-a),g=d,k=this._start,y=this._ts,v=!y,p&&(c||(a=this._zTime),(i||!n)&&(this._zTime=i)),this._repeat){if(S=this._yoyo,_=c+this._rDelay,this._repeat<-1&&i<0)return this.totalTime(_*100+i,n,s);if(g=V(d%_),d===l?(h=this._repeat,g=c):(w=V(d/_),h=~~w,h&&h===w&&(g=c,h--),g>c&&(g=c)),w=ut(this._tTime,_),!a&&this._tTime&&w!==h&&this._tTime-w*_-this._dur<=0&&(w=h),S&&h&1&&(g=c-g,T=1),h!==w&&!this._lock){var j=S&&w&1,C=j===(S&&h&1);if(h<w&&(j=!j),a=j?0:d%c?c:d,this._lock=1,this.render(a||(T?0:V(h*_)),n,!c)._lock=0,this._tTime=d,!n&&this.parent&&pe(this,"onRepeat"),this.vars.repeatRefresh&&!T&&(this.invalidate()._lock=1,w=h),a&&a!==this._time||v!==!this._ts||this.vars.onRepeat&&!this.parent&&!this._act)return this;if(c=this._dur,l=this._tDur,C&&(this._lock=2,a=j?c:-1e-4,this.render(a,!0),this.vars.repeatRefresh&&!T&&this.invalidate()),this._lock=0,!this._ts&&!v)return this}}if(this._hasPause&&!this._forcing&&this._lock<2&&(b=Ps(this,V(a),V(g)),b&&(d-=g-(g=b._start))),this._tTime=d,this._time=g,this._act=!!y,this._initted||(this._onUpdate=this.vars.onUpdate,this._initted=1,this._zTime=i,a=0),!a&&d&&c&&!n&&!w&&(pe(this,"onStart"),this._tTime!==d))return this;if(g>=a&&i>=0)for(f=this._first;f;){if(m=f._next,(f._act||g>=f._start)&&f._ts&&b!==f){if(f.parent!==this)return this.render(i,n,s);if(f.render(f._ts>0?(g-f._start)*f._ts:(f._dirty?f.totalDuration():f._tDur)+(g-f._start)*f._ts,n,s),g!==this._time||!this._ts&&!v){b=0,m&&(d+=this._zTime=-R);break}}f=m}else{f=this._last;for(var M=i<0?i:g;f;){if(m=f._prev,(f._act||M<=f._end)&&f._ts&&b!==f){if(f.parent!==this)return this.render(i,n,s);if(f.render(f._ts>0?(M-f._start)*f._ts:(f._dirty?f.totalDuration():f._tDur)+(M-f._start)*f._ts,n,s||Z&&Ir(f)),g!==this._time||!this._ts&&!v){b=0,m&&(d+=this._zTime=M?-R:R);break}}f=m}}if(b&&!n&&(this.pause(),b.render(g>=a?0:-R)._zTime=g>=a?1:-1,this._ts))return this._start=k,tr(this),this.render(i,n,s);this._onUpdate&&!n&&pe(this,"onUpdate",!0),(d===l&&this._tTime>=this.totalDuration()||!d&&a)&&(k===this._start||Math.abs(y)!==Math.abs(this._ts))&&(this._lock||((i||!c)&&(d===l&&this._ts>0||!d&&this._ts<0)&&Ue(this,1),!n&&!(i<0&&!a)&&(d||a||!l)&&(pe(this,d===l&&i>=0?"onComplete":"onReverseComplete",!0),this._prom&&!(d<l&&this.timeScale()>0)&&this._prom())))}return this},t.add=function(i,n){var s=this;if(Ae(n)||(n=we(this,n,i)),!(i instanceof Mt)){if(re(i))return i.forEach(function(a){return s.add(a,n)}),this;if(Q(i))return this.addLabel(i,n);if(q(i))i=G.delayedCall(0,i);else return this}return this!==i?Me(this,i,n):this},t.getChildren=function(i,n,s,a){i===void 0&&(i=!0),n===void 0&&(n=!0),s===void 0&&(s=!0),a===void 0&&(a=-ve);for(var l=[],c=this._first;c;)c._start>=a&&(c instanceof G?n&&l.push(c):(s&&l.push(c),i&&l.push.apply(l,c.getChildren(!0,n,s)))),c=c._next;return l},t.getById=function(i){for(var n=this.getChildren(1,1,1),s=n.length;s--;)if(n[s].vars.id===i)return n[s]},t.remove=function(i){return Q(i)?this.removeLabel(i):q(i)?this.killTweensOf(i):(i.parent===this&&er(this,i),i===this._recent&&(this._recent=this._last),et(this))},t.totalTime=function(i,n){return arguments.length?(this._forcing=1,!this._dp&&this._ts&&(this._start=V(he.time-(this._ts>0?i/this._ts:(this.totalDuration()-i)/-this._ts))),o.prototype.totalTime.call(this,i,n),this._forcing=0,this):this._tTime},t.addLabel=function(i,n){return this.labels[i]=we(this,n),this},t.removeLabel=function(i){return delete this.labels[i],this},t.addPause=function(i,n,s){var a=G.delayedCall(0,n||Ct,s);return a.data="isPause",this._hasPause=1,Me(this,a,we(this,i))},t.removePause=function(i){var n=this._first;for(i=we(this,i);n;)n._start===i&&n.data==="isPause"&&Ue(n),n=n._next},t.killTweensOf=function(i,n,s){for(var a=this.getTweensOf(i,s),l=a.length;l--;)Le!==a[l]&&a[l].kill(i,n);return this},t.getTweensOf=function(i,n){for(var s=[],a=be(i),l=this._first,c=Ae(n),d;l;)l instanceof G?Ts(l._targets,a)&&(c?(!Le||l._initted&&l._ts)&&l.globalTime(0)<=n&&l.globalTime(l.totalDuration())>n:!n||l.isActive())&&s.push(l):(d=l.getTweensOf(a,n)).length&&s.push.apply(s,d),l=l._next;return s},t.tweenTo=function(i,n){n=n||{};var s=this,a=we(s,i),l=n,c=l.startAt,d=l.onStart,p=l.onStartParams,g=l.immediateRender,f,m=G.to(s,_e({ease:n.ease||"none",lazy:!1,immediateRender:!1,time:a,overwrite:"auto",duration:n.duration||Math.abs((a-(c&&"time"in c?c.time:s._time))/s.timeScale())||R,onStart:function(){if(s.pause(),!f){var _=n.duration||Math.abs((a-(c&&"time"in c?c.time:s._time))/s.timeScale());m._dur!==_&&ht(m,_,0,1).render(m._time,!0,!0),f=1}d&&d.apply(m,p||[])}},n));return g?m.render(0):m},t.tweenFromTo=function(i,n,s){return this.tweenTo(n,_e({startAt:{time:we(this,i)}},s))},t.recent=function(){return this._recent},t.nextLabel=function(i){return i===void 0&&(i=this._time),_i(this,we(this,i))},t.previousLabel=function(i){return i===void 0&&(i=this._time),_i(this,we(this,i),1)},t.currentLabel=function(i){return arguments.length?this.seek(i,!0):this.previousLabel(this._time+R)},t.shiftChildren=function(i,n,s){s===void 0&&(s=0);var a=this._first,l=this.labels,c;for(i=V(i);a;)a._start>=s&&(a._start+=i,a._end+=i),a=a._next;if(n)for(c in l)l[c]>=s&&(l[c]+=i);return et(this)},t.invalidate=function(i){var n=this._first;for(this._lock=0;n;)n.invalidate(i),n=n._next;return o.prototype.invalidate.call(this,i)},t.clear=function(i){i===void 0&&(i=!0);for(var n=this._first,s;n;)s=n._next,this.remove(n),n=s;return this._dp&&(this._time=this._tTime=this._pTime=0),i&&(this.labels={}),et(this)},t.totalDuration=function(i){var n=0,s=this,a=s._last,l=ve,c,d,p;if(arguments.length)return s.timeScale((s._repeat<0?s.duration():s.totalDuration())/(s.reversed()?-i:i));if(s._dirty){for(p=s.parent;a;)c=a._prev,a._dirty&&a.totalDuration(),d=a._start,d>l&&s._sort&&a._ts&&!s._lock?(s._lock=1,Me(s,a,d-a._delay,1)._lock=0):l=d,d<0&&a._ts&&(n-=d,(!p&&!s._dp||p&&p.smoothChildTiming)&&(s._start+=V(d/s._ts),s._time-=d,s._tTime-=d),s.shiftChildren(-d,!1,-1/0),l=0),a._end>n&&a._ts&&(n=a._end),a=c;ht(s,s===I&&s._time>n?s._time:n,1,1),s._dirty=0}return s._tDur},e.updateRoot=function(i){if(I._ts&&(Hi(I,Ht(i,I)),Yi=he.frame),he.frame>=pi){pi+=fe.autoSleep||120;var n=I._first;if((!n||!n._ts)&&fe.autoSleep&&he._listeners.length<2){for(;n&&!n._ts;)n=n._next;n||he.sleep()}}},e}(Mt);_e(ne.prototype,{_lock:0,_hasPause:0,_forcing:0});var Hs=function(e,t,r,i,n,s,a){var l=new oe(this._pt,e,t,0,1,vn,null,n),c=0,d=0,p,g,f,m,h,_,v,b;for(l.b=r,l.e=i,r+="",i+="",(v=~i.indexOf("random("))&&(i=zt(i)),s&&(b=[r,i],s(b,e,t),r=b[0],i=b[1]),g=r.match(or)||[];p=or.exec(i);)m=p[0],h=i.substring(c,p.index),f?f=(f+1)%5:h.substr(-5)==="rgba("&&(f=1),m!==g[d++]&&(_=parseFloat(g[d-1])||0,l._pt={_next:l._pt,p:h||d===1?h:",",s:_,c:m.charAt(1)==="="?ot(_,m)-_:parseFloat(m)-_,m:f&&f<4?Math.round:0},c=or.lastIndex);return l.c=c<i.length?i.substring(c,i.length):"",l.fp=a,(Ii.test(i)||v)&&(l.e=0),this._pt=l,l},Ur=function(e,t,r,i,n,s,a,l,c,d){q(i)&&(i=i(n||0,e,s));var p=e[t],g=r!=="get"?r:q(p)?c?e[t.indexOf("set")||!q(e["get"+t.substr(3)])?t:"get"+t.substr(3)](c):e[t]():p,f=q(p)?c?Js:xn:Wr,m;if(Q(i)&&(~i.indexOf("random(")&&(i=zt(i)),i.charAt(1)==="="&&(m=ot(g,i)+(te(g)||0),(m||m===0)&&(i=m))),!d||g!==i||Cr)return!isNaN(g*i)&&i!==""?(m=new oe(this._pt,e,t,+g||0,i-(g||0),typeof p=="boolean"?ta:wn,0,f),c&&(m.fp=c),a&&m.modifier(a,this,e),this._pt=m):(!p&&!(t in e)&&Lr(t,i),Hs.call(this,e,t,g,i,f,l||fe.stringFilter,c))},Gs=function(e,t,r,i,n){if(q(e)&&(e=kt(e,n,t,r,i)),!Pe(e)||e.style&&e.nodeType||re(e)||$i(e))return Q(e)?kt(e,n,t,r,i):e;var s={},a;for(a in e)s[a]=kt(e[a],n,t,r,i);return s},mn=function(e,t,r,i,n,s){var a,l,c,d;if(ue[e]&&(a=new ue[e]).init(n,a.rawVars?t[e]:Gs(t[e],i,n,s,r),r,i,s)!==!1&&(r._pt=l=new oe(r._pt,n,e,0,1,a.render,a,0,a.priority),r!==at))for(c=r._ptLookup[r._targets.indexOf(n)],d=a._props.length;d--;)c[a._props[d]]=l;return a},Le,Cr,qr=function o(e,t,r){var i=e.vars,n=i.ease,s=i.startAt,a=i.immediateRender,l=i.lazy,c=i.onUpdate,d=i.runBackwards,p=i.yoyoEase,g=i.keyframes,f=i.autoRevert,m=e._dur,h=e._startAt,_=e._targets,v=e.parent,b=v&&v.data==="nested"?v.vars.targets:_,y=e._overwrite==="auto"&&!Ar,k=e.timeline,w=i.easeReverse||p,S,T,j,C,M,O,P,D,E,L,W,B,K;if(k&&(!g||!n)&&(n="none"),e._ease=tt(n,Tt.ease),e._rEase=w&&(tt(w)||e._ease),e._from=!k&&!!i.runBackwards,e._from&&(e.ratio=1),!k||g&&!i.stagger){if(D=_[0]?Je(_[0]).harness:0,B=D&&i[D.prop],S=Xt(i,Br),h&&(h._zTime<0&&h.progress(1),t<0&&d&&a&&!f?h.render(-1,!0):h.revert(d&&m?It:ys),h._lazy=0),s){if(Ue(e._startAt=G.set(_,_e({data:"isStart",overwrite:!1,parent:v,immediateRender:!0,lazy:!h&&se(l),startAt:null,delay:0,onUpdate:c&&function(){return pe(e,"onUpdate")},stagger:0},s))),e._startAt._dp=0,e._startAt._sat=e,t<0&&(Z||!a&&!f)&&e._startAt.revert(It),a&&m&&t<=0&&r<=0){t&&(e._zTime=t);return}}else if(d&&m&&!h){if(t&&(a=!1),j=_e({overwrite:!1,data:"isFromStart",lazy:a&&!h&&se(l),immediateRender:a,stagger:0,parent:v},S),B&&(j[D.prop]=B),Ue(e._startAt=G.set(_,j)),e._startAt._dp=0,e._startAt._sat=e,t<0&&(Z?e._startAt.revert(It):e._startAt.render(-1,!0)),e._zTime=t,!a)o(e._startAt,R,R);else if(!t)return}for(e._pt=e._ptCache=0,l=m&&se(l)||l&&!m,T=0;T<_.length;T++){if(M=_[T],P=M._gsap||Vr(_)[T]._gsap,e._ptLookup[T]=L={},br[P.id]&&Ve.length&&Yt(),W=b===_?T:b.indexOf(M),D&&(E=new D).init(M,B||S,e,W,b)!==!1&&(e._pt=C=new oe(e._pt,M,E.name,0,1,E.render,E,0,E.priority),E._props.forEach(function(je){L[je]=C}),E.priority&&(O=1)),!D||B)for(j in S)ue[j]&&(E=mn(j,S,e,W,M,b))?E.priority&&(O=1):L[j]=C=Ur.call(e,M,j,"get",S[j],W,b,0,i.stringFilter);e._op&&e._op[T]&&e.kill(M,e._op[T]),y&&e._pt&&(Le=e,I.killTweensOf(M,L,e.globalTime(t)),K=!e.parent,Le=0),e._pt&&l&&(br[P.id]=1)}O&&bn(e),e._onInit&&e._onInit(e)}e._onUpdate=c,e._initted=(!e._op||e._pt)&&!K,g&&t<=0&&k.render(ve,!0,!0)},Ks=function(e,t,r,i,n,s,a,l){var c=(e._pt&&e._ptCache||(e._ptCache={}))[t],d,p,g,f;if(!c)for(c=e._ptCache[t]=[],g=e._ptLookup,f=e._targets.length;f--;){if(d=g[f][t],d&&d.d&&d.d._pt)for(d=d.d._pt;d&&d.p!==t&&d.fp!==t;)d=d._next;if(!d)return Cr=1,e.vars[t]="+=0",qr(e,a),Cr=0,l?jt(t+" not eligible for reset. Try splitting into individual properties"):1;c.push(d)}for(f=c.length;f--;)p=c[f],d=p._pt||p,d.s=(i||i===0)&&!n?i:d.s+(i||0)+s*d.c,d.c=r-d.s,p.e&&(p.e=Y(r)+te(p.e)),p.b&&(p.b=d.s+te(p.b))},Qs=function(e,t){var r=e[0]?Je(e[0]).harness:0,i=r&&r.aliases,n,s,a,l;if(!i)return t;n=dt({},t);for(s in i)if(s in n)for(l=i[s].split(","),a=l.length;a--;)n[l[a]]=n[s];return n},Zs=function(e,t,r,i){var n=t.ease||i||"power1.inOut",s,a;if(re(t))a=r[e]||(r[e]=[]),t.forEach(function(l,c){return a.push({t:c/(t.length-1)*100,v:l,e:n})});else for(s in t)a=r[s]||(r[s]=[]),s==="ease"||a.push({t:parseFloat(e),v:t[s],e:n})},kt=function(e,t,r,i,n){return q(e)?e.call(t,r,i,n):Q(e)&&~e.indexOf("random(")?zt(e):e},Kt=$r+"repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase,easeReverse,autoRevert",_n={};ae(Kt+",id,stagger,delay,duration,paused,scrollTrigger",function(o){return _n[o]=1});Kt=Kt.split(",");var G=function(o){Li(e,o);function e(r,i,n,s){var a;typeof i=="number"&&(n.duration=i,i=n,n=null),a=o.call(this,s?i:bt(i))||this;var l=a.vars,c=l.duration,d=l.delay,p=l.immediateRender,g=l.stagger,f=l.overwrite,m=l.keyframes,h=l.defaults,_=l.scrollTrigger,v=i.parent||I,b=(re(r)||$i(r)?Ae(r[0]):"length"in i)?[r]:be(r),y,k,w,S,T,j,C,M;if(a._targets=b.length?Vr(b):jt("GSAP target "+r+" not found. https://gsap.com",!fe.nullTargetWarn)||[],a._ptLookup=[],a._overwrite=f,m||g||Bt(c)||Bt(d)){i=a.vars;var O=i.easeReverse||i.yoyoEase;if(y=a.timeline=new ne({data:"nested",defaults:h||{},targets:v&&v.data==="nested"?v.vars.targets:b}),y.kill(),y.parent=y._dp=Ne(a),y._start=0,g||Bt(c)||Bt(d)){if(S=b.length,C=g&&nn(g),Pe(g))for(T in g)~Kt.indexOf(T)&&(M||(M={}),M[T]=g[T]);for(k=0;k<S;k++)w=Xt(i,_n),w.stagger=0,O&&(w.easeReverse=O),M&&dt(w,M),j=b[k],w.duration=+kt(c,Ne(a),k,j,b),w.delay=(+kt(d,Ne(a),k,j,b)||0)-a._delay,!g&&S===1&&w.delay&&(a._delay=d=w.delay,a._start+=d,w.delay=0),y.to(j,w,C?C(k,j,b):0),y._ease=N.none;y.duration()?c=d=0:a.timeline=0}else if(m){bt(_e(y.vars.defaults,{ease:"none"})),y._ease=tt(m.ease||i.ease||"none");var P=0,D,E,L;if(re(m))m.forEach(function(W){return y.to(b,W,">")}),y.duration();else{w={};for(T in m)T==="ease"||T==="easeEach"||Zs(T,m[T],w,m.easeEach);for(T in w)for(D=w[T].sort(function(W,B){return W.t-B.t}),P=0,k=0;k<D.length;k++)E=D[k],L={ease:E.e,duration:(E.t-(k?D[k-1].t:0))/100*c},L[T]=E.v,y.to(b,L,P),P+=L.duration;y.duration()<c&&y.to({},{duration:c-y.duration()})}}c||a.duration(c=y.duration())}else a.timeline=0;return f===!0&&!Ar&&(Le=Ne(a),I.killTweensOf(b),Le=0),Me(v,Ne(a),n),i.reversed&&a.reverse(),i.paused&&a.paused(!0),(p||!c&&!m&&a._start===V(v._time)&&se(p)&&Ss(Ne(a))&&v.data!=="nested")&&(a._tTime=-R,a.render(Math.max(0,-d)||0)),_&&Ji(Ne(a),_),a}var t=e.prototype;return t.render=function(i,n,s){var a=this._time,l=this._tDur,c=this._dur,d=i<0,p=i>l-R&&!d?l:i<R?0:i,g,f,m,h,_,v,b,y;if(!c)Os(this,i,n,s);else if(p!==this._tTime||!i||s||!this._initted&&this._tTime||this._startAt&&this._zTime<0!==d||this._lazy){if(g=p,y=this.timeline,this._repeat){if(h=c+this._rDelay,this._repeat<-1&&d)return this.totalTime(h*100+i,n,s);if(g=V(p%h),p===l?(m=this._repeat,g=c):(_=V(p/h),m=~~_,m&&m===_?(g=c,m--):g>c&&(g=c)),v=this._yoyo&&m&1,v&&(g=c-g),_=ut(this._tTime,h),g===a&&!s&&this._initted&&m===_)return this._tTime=p,this;m!==_&&this.vars.repeatRefresh&&!v&&!this._lock&&g!==h&&this._initted&&(this._lock=s=1,this.render(V(h*m),!0).invalidate()._lock=0)}if(!this._initted){if(en(this,d?i:g,s,n,p))return this._tTime=0,this;if(a!==this._time&&!(s&&this.vars.repeatRefresh&&m!==_))return this;if(c!==this._dur)return this.render(i,n,s)}if(this._rEase){var k=g<a;if(k!==this._inv){var w=k?a:c-a;this._inv=k,this._from&&(this.ratio=1-this.ratio),this._invRatio=this.ratio,this._invTime=a,this._invRecip=w?(k?-1:1)/w:0,this._invScale=k?-this.ratio:1-this.ratio,this._invEase=k?this._rEase:this._ease}this.ratio=b=this._invRatio+this._invScale*this._invEase((g-this._invTime)*this._invRecip)}else this.ratio=b=this._ease(g/c);if(this._from&&(this.ratio=b=1-b),this._tTime=p,this._time=g,!this._act&&this._ts&&(this._act=1,this._lazy=0),!a&&p&&!n&&!_&&(pe(this,"onStart"),this._tTime!==p))return this;for(f=this._pt;f;)f.r(b,f.d),f=f._next;y&&y.render(i<0?i:y._dur*y._ease(g/this._dur),n,s)||this._startAt&&(this._zTime=i),this._onUpdate&&!n&&(d&&yr(this,i,n,s),pe(this,"onUpdate")),this._repeat&&m!==_&&this.vars.onRepeat&&!n&&this.parent&&pe(this,"onRepeat"),(p===this._tDur||!p)&&this._tTime===p&&(d&&!this._onUpdate&&yr(this,i,!0,!0),(i||!c)&&(p===this._tDur&&this._ts>0||!p&&this._ts<0)&&Ue(this,1),!n&&!(d&&!a)&&(p||a||v)&&(pe(this,p===l?"onComplete":"onReverseComplete",!0),this._prom&&!(p<l&&this.timeScale()>0)&&this._prom()))}return this},t.targets=function(){return this._targets},t.invalidate=function(i){return(!i||!this.vars.runBackwards)&&(this._startAt=0),this._pt=this._op=this._onUpdate=this._lazy=this.ratio=0,this._ptLookup=[],this.timeline&&this.timeline.invalidate(i),o.prototype.invalidate.call(this,i)},t.resetTo=function(i,n,s,a,l){St||he.wake(),this._ts||this.play();var c=Math.min(this._dur,(this._dp._time-this._start)*this._ts),d;return this._initted||qr(this,c),d=this._ease(c/this._dur),Ks(this,i,n,s,a,d,c,l)?this.resetTo(i,n,s,a,1):(rr(this,0),this.parent||Qi(this._dp,this,"_first","_last",this._dp._sort?"_start":0),this.render(0))},t.kill=function(i,n){if(n===void 0&&(n="all"),!i&&(!n||n==="all"))return this._lazy=this._pt=0,this.parent?xt(this):this.scrollTrigger&&this.scrollTrigger.kill(!!Z),this;if(this.timeline){var s=this.timeline.totalDuration();return this.timeline.killTweensOf(i,n,Le&&Le.vars.overwrite!==!0)._first||xt(this),this.parent&&s!==this.timeline.totalDuration()&&ht(this,this._dur*this.timeline._tDur/s,0,1),this}var a=this._targets,l=i?be(i):a,c=this._ptLookup,d=this._pt,p,g,f,m,h,_,v;if((!n||n==="all")&&Cs(a,l))return n==="all"&&(this._pt=0),xt(this);for(p=this._op=this._op||[],n!=="all"&&(Q(n)&&(h={},ae(n,function(b){return h[b]=1}),n=h),n=Qs(a,n)),v=a.length;v--;)if(~l.indexOf(a[v])){g=c[v],n==="all"?(p[v]=n,m=g,f={}):(f=p[v]=p[v]||{},m=n);for(h in m)_=g&&g[h],_&&((!("kill"in _.d)||_.d.kill(h)===!0)&&er(this,_,"_pt"),delete g[h]),f!=="all"&&(f[h]=1)}return this._initted&&!this._pt&&d&&xt(this),this},e.to=function(i,n){return new e(i,n,arguments[2])},e.from=function(i,n){return yt(1,arguments)},e.delayedCall=function(i,n,s,a){return new e(n,0,{immediateRender:!1,lazy:!1,overwrite:!1,delay:i,onComplete:n,onReverseComplete:n,onCompleteParams:s,onReverseCompleteParams:s,callbackScope:a})},e.fromTo=function(i,n,s){return yt(2,arguments)},e.set=function(i,n){return n.duration=0,n.repeatDelay||(n.repeat=0),new e(i,n)},e.killTweensOf=function(i,n,s){return I.killTweensOf(i,n,s)},e}(Mt);_e(G.prototype,{_targets:[],_lazy:0,_startAt:0,_op:0,_onInit:0});ae("staggerTo,staggerFrom,staggerFromTo",function(o){G[o]=function(){var e=new ne,t=kr.call(arguments,0);return t.splice(o==="staggerFromTo"?5:4,0,0),e[o].apply(e,t)}});var Wr=function(e,t,r){return e[t]=r},xn=function(e,t,r){return e[t](r)},Js=function(e,t,r,i){return e[t](i.fp,r)},ea=function(e,t,r){return e.setAttribute(t,r)},Yr=function(e,t){return q(e[t])?xn:Rr(e[t])&&e.setAttribute?ea:Wr},wn=function(e,t){return t.set(t.t,t.p,Math.round((t.s+t.c*e)*1e6)/1e6,t)},ta=function(e,t){return t.set(t.t,t.p,!!(t.s+t.c*e),t)},vn=function(e,t){var r=t._pt,i="";if(!e&&t.b)i=t.b;else if(e===1&&t.e)i=t.e;else{for(;r;)i=r.p+(r.m?r.m(r.s+r.c*e):Math.round((r.s+r.c*e)*1e4)/1e4)+i,r=r._next;i+=t.c}t.set(t.t,t.p,i,t)},Xr=function(e,t){for(var r=t._pt;r;)r.r(e,r.d),r=r._next},ra=function(e,t,r,i){for(var n=this._pt,s;n;)s=n._next,n.p===i&&n.modifier(e,t,r),n=s},ia=function(e){for(var t=this._pt,r,i;t;)i=t._next,t.p===e&&!t.op||t.op===e?er(this,t,"_pt"):t.dep||(r=1),t=i;return!r},na=function(e,t,r,i){i.mSet(e,t,i.m.call(i.tween,r,i.mt),i)},bn=function(e){for(var t=e._pt,r,i,n,s;t;){for(r=t._next,i=n;i&&i.pr>t.pr;)i=i._next;(t._prev=i?i._prev:s)?t._prev._next=t:n=t,(t._next=i)?i._prev=t:s=t,t=r}e._pt=n},oe=function(){function o(t,r,i,n,s,a,l,c,d){this.t=r,this.s=n,this.c=s,this.p=i,this.r=a||wn,this.d=l||this,this.set=c||Wr,this.pr=d||0,this._next=t,t&&(t._prev=this)}var e=o.prototype;return e.modifier=function(r,i,n){this.mSet=this.mSet||this.set,this.set=na,this.m=r,this.mt=n,this.tween=i},o}();ae($r+"parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger,easeReverse",function(o){return Br[o]=1});me.TweenMax=me.TweenLite=G;me.TimelineLite=me.TimelineMax=ne;I=new ne({sortChildren:!1,defaults:Tt,autoRemoveChildren:!0,id:"root",smoothChildTiming:!0});fe.stringFilter=pn;var rt=[],qt={},sa=[],wi=0,aa=0,hr=function(e){return(qt[e]||sa).map(function(t){return t()})},Ot=function(){var e=Date.now(),t=[];e-wi>2&&(hr("matchMediaInit"),rt.forEach(function(r){var i=r.queries,n=r.conditions,s,a,l,c;for(a in i)s=Se.matchMedia(i[a]).matches,s&&(l=1),s!==n[a]&&(n[a]=s,c=1);c&&(r.revert(),l&&t.push(r))}),hr("matchMediaRevert"),t.forEach(function(r){return r.onMatch(r,function(i){return r.add(null,i)})}),wi=e,hr("matchMedia"))},yn=function(){function o(t,r){this.selector=r&&Tr(r),this.data=[],this._r=[],this.isReverted=!1,this.id=aa++,t&&this.add(t)}var e=o.prototype;return e.add=function(r,i,n){q(r)&&(n=i,i=r,r=q);var s=this,a=function(){var c=$,d=s.selector,p;return c&&c!==s&&c.data.push(s),n&&(s.selector=Tr(n)),$=s,p=i.apply(s,arguments),q(p)&&s._r.push(p),$=c,s.selector=d,s.isReverted=!1,p};return s.last=a,r===q?a(s,function(l){return s.add(null,l)}):r?s[r]=a:a},e.ignore=function(r){var i=$;$=null,r(this),$=i},e.getTweens=function(){var r=[];return this.data.forEach(function(i){return i instanceof o?r.push.apply(r,i.getTweens()):i instanceof G&&!(i.parent&&i.parent.data==="nested")&&r.push(i)}),r},e.clear=function(){this._r.length=this.data.length=0},e.kill=function(r,i){var n=this;if(r?function(){for(var a=n.getTweens(),l=n.data.length,c;l--;)c=n.data[l],c.data==="isFlip"&&(c.revert(),c.getChildren(!0,!0,!1).forEach(function(d){return a.splice(a.indexOf(d),1)}));for(a.map(function(d){return{g:d._dur||d._delay||d._sat&&!d._sat.vars.immediateRender?d.globalTime(0):-1/0,t:d}}).sort(function(d,p){return p.g-d.g||-1/0}).forEach(function(d){return d.t.revert(r)}),l=n.data.length;l--;)c=n.data[l],c instanceof ne?c.data!=="nested"&&(c.scrollTrigger&&c.scrollTrigger.revert(),c.kill()):!(c instanceof G)&&c.revert&&c.revert(r);n._r.forEach(function(d){return d(r,n)}),n.isReverted=!0}():this.data.forEach(function(a){return a.kill&&a.kill()}),this.clear(),i){for(var s=rt.length;s--;)rt[s].id===this.id&&rt.splice(s,1);this._mqs&&this._mqs.forEach(function(a){return a.removeListener?a.removeListener(Ot):a.removeEventListener("change",Ot)}),this._mqs=null}},e.revert=function(r){this.kill(r||{})},o}(),oa=function(){function o(t){this.contexts=[],this.scope=t,$&&$.data.push(this)}var e=o.prototype;return e.add=function(r,i,n){Pe(r)||(r={matches:r});var s=new yn(0,n||this.scope),a=s.conditions={},l,c,d;$&&!s.selector&&(s.selector=$.selector),this.contexts.push(s),i=s.add("onMatch",i),s.queries=r;for(c in r)c==="all"?d=1:(l=Se.matchMedia(r[c]),l&&(rt.indexOf(s)<0&&rt.push(s),(a[c]=l.matches)&&(d=1),l.addListener?l.addListener(Ot):l.addEventListener("change",Ot),(s._mqs||(s._mqs=[])).push(l)));return d&&i(s,function(p){return s.add(null,p)}),this},e.revert=function(r){this.kill(r||{})},e.kill=function(r){this.contexts.forEach(function(i){return i.kill(r,!0)})},o}(),Qt={registerPlugin:function(){for(var e=arguments.length,t=new Array(e),r=0;r<e;r++)t[r]=arguments[r];t.forEach(function(i){return dn(i)})},timeline:function(e){return new ne(e)},getTweensOf:function(e,t){return I.getTweensOf(e,t)},getProperty:function(e,t,r,i){Q(e)&&(e=be(e)[0]);var n=Je(e||{}).get,s=r?Ki:Gi;return r==="native"&&(r=""),e&&(t?s((ue[t]&&ue[t].get||n)(e,t,r,i)):function(a,l,c){return s((ue[a]&&ue[a].get||n)(e,a,l,c))})},quickSetter:function(e,t,r){if(e=be(e),e.length>1){var i=e.map(function(d){return ce.quickSetter(d,t,r)}),n=i.length;return function(d){for(var p=n;p--;)i[p](d)}}e=e[0]||{};var s=ue[t],a=Je(e),l=a.harness&&(a.harness.aliases||{})[t]||t,c=s?function(d){var p=new s;at._pt=0,p.init(e,r?d+r:d,at,0,[e]),p.render(1,p),at._pt&&Xr(1,at)}:a.set(e,l);return s?c:function(d){return c(e,l,r?d+r:d,a,1)}},quickTo:function(e,t,r){var i,n=ce.to(e,_e((i={},i[t]="+=0.1",i.paused=!0,i.stagger=0,i),r||{})),s=function(l,c,d){return n.resetTo(t,l,c,d)};return s.tween=n,s},isTweening:function(e){return I.getTweensOf(e,!0).length>0},defaults:function(e){return e&&e.ease&&(e.ease=tt(e.ease,Tt.ease)),gi(Tt,e||{})},config:function(e){return gi(fe,e||{})},registerEffect:function(e){var t=e.name,r=e.effect,i=e.plugins,n=e.defaults,s=e.extendTimeline;(i||"").split(",").forEach(function(a){return a&&!ue[a]&&!me[a]&&jt(t+" effect requires "+a+" plugin.")}),lr[t]=function(a,l,c){return r(be(a),_e(l||{},n),c)},s&&(ne.prototype[t]=function(a,l,c){return this.add(lr[t](a,Pe(l)?l:(c=l)&&{},this),c)})},registerEase:function(e,t){N[e]=tt(t)},parseEase:function(e,t){return arguments.length?tt(e,t):N},getById:function(e){return I.getById(e)},exportRoot:function(e,t){e===void 0&&(e={});var r=new ne(e),i,n;for(r.smoothChildTiming=se(e.smoothChildTiming),I.remove(r),r._dp=0,r._time=r._tTime=I._time,i=I._first;i;)n=i._next,(t||!(!i._dur&&i instanceof G&&i.vars.onComplete===i._targets[0]))&&Me(r,i,i._start-i._delay),i=n;return Me(I,r,0),r},context:function(e,t){return e?new yn(e,t):$},matchMedia:function(e){return new oa(e)},matchMediaRefresh:function(){return rt.forEach(function(e){var t=e.conditions,r,i;for(i in t)t[i]&&(t[i]=!1,r=1);r&&e.revert()})||Ot()},addEventListener:function(e,t){var r=qt[e]||(qt[e]=[]);~r.indexOf(t)||r.push(t)},removeEventListener:function(e,t){var r=qt[e],i=r&&r.indexOf(t);i>=0&&r.splice(i,1)},utils:{wrap:Ls,wrapYoyo:Bs,distribute:nn,random:an,snap:sn,normalize:Fs,getUnit:te,clamp:Ds,splitColor:un,toArray:be,selector:Tr,mapRange:ln,pipe:Rs,unitize:Es,interpolate:$s,shuffle:rn},install:qi,effects:lr,ticker:he,updateRoot:ne.updateRoot,plugins:ue,globalTimeline:I,core:{PropTween:oe,globals:Wi,Tween:G,Timeline:ne,Animation:Mt,getCache:Je,_removeLinkedListItem:er,reverting:function(){return Z},context:function(e){return e&&$&&($.data.push(e),e._ctx=$),$},suppressOverwrites:function(e){return Ar=e}}};ae("to,from,fromTo,delayedCall,set,killTweensOf",function(o){return Qt[o]=G[o]});he.add(ne.updateRoot);at=Qt.to({},{duration:0});var la=function(e,t){for(var r=e._pt;r&&r.p!==t&&r.op!==t&&r.fp!==t;)r=r._next;return r},ca=function(e,t){var r=e._targets,i,n,s;for(i in t)for(n=r.length;n--;)s=e._ptLookup[n][i],s&&(s=s.d)&&(s._pt&&(s=la(s,i)),s&&s.modifier&&s.modifier(t[i],e,r[n],i))},pr=function(e,t){return{name:e,headless:1,rawVars:1,init:function(i,n,s){s._onInit=function(a){var l,c;if(Q(n)&&(l={},ae(n,function(d){return l[d]=1}),n=l),t){l={};for(c in n)l[c]=t(n[c]);n=l}ca(a,n)}}}},ce=Qt.registerPlugin({name:"attr",init:function(e,t,r,i,n){var s,a,l;this.tween=r;for(s in t)l=e.getAttribute(s)||"",a=this.add(e,"setAttribute",(l||0)+"",t[s],i,n,0,0,s),a.op=s,a.b=l,this._props.push(s)},render:function(e,t){for(var r=t._pt;r;)Z?r.set(r.t,r.p,r.b,r):r.r(e,r.d),r=r._next}},{name:"endArray",headless:1,init:function(e,t){for(var r=t.length;r--;)this.add(e,r,e[r]||0,t[r],0,0,0,0,0,1)}},pr("roundProps",jr),pr("modifiers"),pr("snap",sn))||Qt;G.version=ne.version=ce.version="3.15.1";Ui=1;Er()&&pt();N.Power0;N.Power1;N.Power2;N.Power3;N.Power4;N.Linear;N.Quad;N.Cubic;N.Quart;N.Quint;N.Strong;N.Elastic;N.Back;N.SteppedEase;N.Bounce;N.Sine;N.Expo;N.Circ;/*!
 * CSSPlugin 3.15.1
 * https://gsap.com
 *
 * Copyright 2008-2026, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
*/var vi,Be,lt,Hr,Ze,bi,Gr,da=function(){return typeof window!="undefined"},Re={},Qe=180/Math.PI,ct=Math.PI/180,nt=Math.atan2,yi=1e8,Kr=/([A-Z])/g,ua=/(left|right|width|margin|padding|x)/i,ha=/[\s,\(]\S/,Oe={autoAlpha:"opacity,visibility",scale:"scaleX,scaleY",alpha:"opacity"},zr=function(e,t){return t.set(t.t,t.p,Math.round((t.s+t.c*e)*1e4)/1e4+t.u,t)},pa=function(e,t){return t.set(t.t,t.p,e===1?t.e:Math.round((t.s+t.c*e)*1e4)/1e4+t.u,t)},ga=function(e,t){return t.set(t.t,t.p,e?Math.round((t.s+t.c*e)*1e4)/1e4+t.u:t.b,t)},fa=function(e,t){return t.set(t.t,t.p,e===1?t.e:e?Math.round((t.s+t.c*e)*1e4)/1e4+t.u:t.b,t)},ma=function(e,t){var r=t.s+t.c*e;t.set(t.t,t.p,~~(r+(r<0?-.5:.5))+t.u,t)},kn=function(e,t){return t.set(t.t,t.p,e?t.e:t.b,t)},Tn=function(e,t){return t.set(t.t,t.p,e!==1?t.b:t.e,t)},_a=function(e,t,r){return e.style[t]=r},xa=function(e,t,r){return e.style.setProperty(t,r)},wa=function(e,t,r){return e._gsap[t]=r},va=function(e,t,r){return e._gsap.scaleX=e._gsap.scaleY=r},ba=function(e,t,r,i,n){var s=e._gsap;s.scaleX=s.scaleY=r,s.renderTransform(n,s)},ya=function(e,t,r,i,n){var s=e._gsap;s[t]=r,s.renderTransform(n,s)},U="transform",le=U+"Origin",ka=function o(e,t){var r=this,i=this.target,n=i.style,s=i._gsap;if(e in Re&&n){if(this.tfm=this.tfm||{},e!=="transform")e=Oe[e]||e,~e.indexOf(",")?e.split(",").forEach(function(a){return r.tfm[a]=De(i,a)}):this.tfm[e]=s.x?s[e]:De(i,e),e===le&&(this.tfm.zOrigin=s.zOrigin);else return Oe.transform.split(",").forEach(function(a){return o.call(r,a,t)});if(this.props.indexOf(U)>=0)return;s.svg&&(this.svgo=i.getAttribute("data-svg-origin"),this.props.push(le,t,"")),e=U}(n||t)&&this.props.push(e,t,n[e])},jn=function(e){e.translate&&(e.removeProperty("translate"),e.removeProperty("scale"),e.removeProperty("rotate"))},Ta=function(){var e=this.props,t=this.target,r=t.style,i=t._gsap,n,s;for(n=0;n<e.length;n+=3)e[n+1]?e[n+1]===2?t[e[n]](e[n+2]):t[e[n]]=e[n+2]:e[n+2]?r[e[n]]=e[n+2]:r.removeProperty(e[n].substr(0,2)==="--"?e[n]:e[n].replace(Kr,"-$1").toLowerCase());if(this.tfm){for(s in this.tfm)i[s]=this.tfm[s];i.svg&&(i.renderTransform(),t.setAttribute("data-svg-origin",this.svgo||"")),n=Gr(),(!n||!n.isStart)&&!r[U]&&(jn(r),i.zOrigin&&r[le]&&(r[le]+=" "+i.zOrigin+"px",i.zOrigin=0,i.renderTransform()),i.uncache=1)}},Cn=function(e,t){var r={target:e,props:[],revert:Ta,save:ka};return e._gsap||ce.core.getCache(e),t&&e.style&&e.nodeType&&t.split(",").forEach(function(i){return r.save(i)}),r},zn,Sr=function(e,t){var r=Be.createElementNS?Be.createElementNS((t||"http://www.w3.org/1999/xhtml").replace(/^https/,"http"),e):Be.createElement(e);return r&&r.style?r:Be.createElement(e)},ge=function o(e,t,r){var i=getComputedStyle(e);return i[t]||i.getPropertyValue(t.replace(Kr,"-$1").toLowerCase())||i.getPropertyValue(t)||!r&&o(e,gt(t)||t,1)||""},ki="O,Moz,ms,Ms,Webkit".split(","),gt=function(e,t,r){var i=t||Ze,n=i.style,s=5;if(e in n&&!r)return e;for(e=e.charAt(0).toUpperCase()+e.substr(1);s--&&!(ki[s]+e in n););return s<0?null:(s===3?"ms":s>=0?ki[s]:"")+e},Mr=function(){da()&&window.document&&(vi=window,Be=vi.document,lt=Be.documentElement,Ze=Sr("div")||{style:{}},Sr("div"),U=gt(U),le=U+"Origin",Ze.style.cssText="border-width:0;line-height:0;position:absolute;padding:0",zn=!!gt("perspective"),Gr=ce.core.reverting,Hr=1)},Ti=function(e){var t=e.ownerSVGElement,r=Sr("svg",t&&t.getAttribute("xmlns")||"http://www.w3.org/2000/svg"),i=e.cloneNode(!0),n;i.style.display="block",r.appendChild(i),lt.appendChild(r);try{n=i.getBBox()}catch{}return r.removeChild(i),lt.removeChild(r),n},ji=function(e,t){for(var r=t.length;r--;)if(e.hasAttribute(t[r]))return e.getAttribute(t[r])},Sn=function(e){var t,r;try{t=e.getBBox()}catch{t=Ti(e),r=1}return t&&(t.width||t.height)||r||(t=Ti(e)),t&&!t.width&&!t.x&&!t.y?{x:+ji(e,["x","cx","x1"])||0,y:+ji(e,["y","cy","y1"])||0,width:0,height:0}:t},Mn=function(e){return!!(e.getCTM&&(!e.parentNode||e.ownerSVGElement)&&Sn(e))},qe=function(e,t){if(t){var r=e.style,i;t in Re&&t!==le&&(t=U),r.removeProperty?(i=t.substr(0,2),(i==="ms"||t.substr(0,6)==="webkit")&&(t="-"+t),r.removeProperty(i==="--"?t:t.replace(Kr,"-$1").toLowerCase())):r.removeAttribute(t)}},$e=function(e,t,r,i,n,s){var a=new oe(e._pt,t,r,0,1,s?Tn:kn);return e._pt=a,a.b=i,a.e=n,e._props.push(r),a},Ci={deg:1,rad:1,turn:1},ja={grid:1,flex:1},We=function o(e,t,r,i){var n=parseFloat(r)||0,s=(r+"").trim().substr((n+"").length)||"px",a=Ze.style,l=ua.test(t),c=e.tagName.toLowerCase()==="svg",d=(c?"client":"offset")+(l?"Width":"Height"),p=100,g=i==="px",f=i==="%",m,h,_,v;if(i===s||!n||Ci[i]||Ci[s])return n;if(s!=="px"&&!g&&(n=o(e,t,r,"px")),v=e.getCTM&&Mn(e),(f||s==="%")&&(Re[t]||~t.indexOf("adius")))return m=v?e.getBBox()[l?"width":"height"]:e[d],Y(f?n/m*p:n/100*m);if(a[l?"width":"height"]=p+(g?s:i),h=i!=="rem"&&~t.indexOf("adius")||i==="em"&&e.appendChild&&!c?e:e.parentNode,v&&(h=(e.ownerSVGElement||{}).parentNode),(!h||h===Be||!h.appendChild)&&(h=Be.body),_=h._gsap,_&&f&&_.width&&l&&_.time===he.time&&!_.uncache)return Y(n/_.width*p);if(f&&(t==="height"||t==="width")){var b=e.style[t];e.style[t]=p+i,m=e[d],b?e.style[t]=b:qe(e,t)}else(f||s==="%")&&!ja[ge(h,"display")]&&(a.position=ge(e,"position")),h===e&&(a.position="static"),h.appendChild(Ze),m=Ze[d],h.removeChild(Ze),a.position="absolute";return l&&f&&(_=Je(h),_.time=he.time,_.width=h[d]),Y(g?m*n/p:m&&n?p/m*n:0)},De=function(e,t,r,i){var n;return Hr||Mr(),t in Oe&&t!=="transform"&&(t=Oe[t],~t.indexOf(",")&&(t=t.split(",")[0])),Re[t]&&t!=="transform"?(n=Nt(e,i),n=t!=="transformOrigin"?n[t]:n.svg?n.origin:Jt(ge(e,le))+" "+n.zOrigin+"px"):(n=e.style[t],(!n||n==="auto"||i||~(n+"").indexOf("calc("))&&(n=Zt[t]&&Zt[t](e,t,r)||ge(e,t)||Xi(e,t)||(t==="opacity"?1:0))),r&&!~(n+"").trim().indexOf(" ")?We(e,t,n,r)+r:n},Ca=function(e,t,r,i){if(!r||r==="none"){var n=gt(t,e,1),s=n&&ge(e,n,1);s&&s!==r?(t=n,r=s):t==="borderColor"&&(r=ge(e,"borderTopColor"))}var a=new oe(this._pt,e.style,t,0,1,vn),l=0,c=0,d,p,g,f,m,h,_,v,b,y,k,w;if(a.b=r,a.e=i,r+="",i+="",i.substring(0,6)==="var(--"&&(i=ge(e,i.substring(4,i.indexOf(")")))),i==="auto"&&(h=e.style[t],e.style[t]=i,i=ge(e,t)||i,h?e.style[t]=h:qe(e,t)),d=[r,i],pn(d),r=d[0],i=d[1],g=r.match(st)||[],w=i.match(st)||[],w.length){for(;p=st.exec(i);)_=p[0],b=i.substring(l,p.index),m?m=(m+1)%5:(b.substr(-5)==="rgba("||b.substr(-5)==="hsla(")&&(m=1),_!==(h=g[c++]||"")&&(f=parseFloat(h)||0,k=h.substr((f+"").length),_.charAt(1)==="="&&(_=ot(f,_)+k),v=parseFloat(_),y=_.substr((v+"").length),l=st.lastIndex-y.length,y||(y=y||fe.units[t]||k,l===i.length&&(i+=y,a.e+=y)),k!==y&&(f=We(e,t,h,y)||0),a._pt={_next:a._pt,p:b||c===1?b:",",s:f,c:v-f,m:m&&m<4||t==="zIndex"?Math.round:0});a.c=l<i.length?i.substring(l,i.length):""}else a.r=t==="display"&&i==="none"?Tn:kn;return Ii.test(i)&&(a.e=0),this._pt=a,a},zi={top:"0%",bottom:"100%",left:"0%",right:"100%",center:"50%"},za=function(e){var t=e.split(" "),r=t[0],i=t[1]||"50%";return(r==="top"||r==="bottom"||i==="left"||i==="right")&&(e=r,r=i,i=e),t[0]=zi[r]||r,t[1]=zi[i]||i,t.join(" ")},Sa=function(e,t){if(t.tween&&t.tween._time===t.tween._dur){var r=t.t,i=r.style,n=t.u,s=r._gsap,a,l,c;if(n==="all"||n===!0)i.cssText="",l=1;else for(n=n.split(","),c=n.length;--c>-1;)a=n[c],Re[a]&&(l=1,a=a==="transformOrigin"?le:U),qe(r,a);l&&(qe(r,U),s&&(s.svg&&r.removeAttribute("transform"),i.scale=i.rotate=i.translate="none",Nt(r,1),s.uncache=1,jn(i)))}},Zt={clearProps:function(e,t,r,i,n){if(n.data!=="isFromStart"){var s=e._pt=new oe(e._pt,t,r,0,0,Sa);return s.u=i,s.pr=-10,s.tween=n,e._props.push(r),1}}},Pt=[1,0,0,1,0,0],On={},Pn=function(e){return e==="matrix(1, 0, 0, 1, 0, 0)"||e==="none"||!e},Si=function(e){var t=ge(e,U);return Pn(t)?Pt:t.substr(7).match(Vi).map(Y)},Qr=function(e,t){var r=e._gsap||Je(e),i=e.style,n=Si(e),s,a,l,c;return r.svg&&e.getAttribute("transform")?(l=e.transform.baseVal.consolidate().matrix,n=[l.a,l.b,l.c,l.d,l.e,l.f],n.join(",")==="1,0,0,1,0,0"?Pt:n):(n===Pt&&!e.offsetParent&&e!==lt&&!r.svg&&(l=i.display,i.display="block",s=e.parentNode,(!s||!e.offsetParent&&!e.getBoundingClientRect().width)&&(c=1,a=e.nextElementSibling,lt.appendChild(e)),n=Si(e),l?i.display=l:qe(e,"display"),c&&(a?s.insertBefore(e,a):s?s.appendChild(e):lt.removeChild(e))),t&&n.length>6?[n[0],n[1],n[4],n[5],n[12],n[13]]:n)},Or=function(e,t,r,i,n,s){var a=e._gsap,l=n||Qr(e,!0),c=a.xOrigin||0,d=a.yOrigin||0,p=a.xOffset||0,g=a.yOffset||0,f=l[0],m=l[1],h=l[2],_=l[3],v=l[4],b=l[5],y=t.split(" "),k=parseFloat(y[0])||0,w=parseFloat(y[1])||0,S,T,j,C;r?l!==Pt&&(T=f*_-m*h)&&(j=k*(_/T)+w*(-h/T)+(h*b-_*v)/T,C=k*(-m/T)+w*(f/T)-(f*b-m*v)/T,k=j,w=C):(S=Sn(e),k=S.x+(~y[0].indexOf("%")?k/100*S.width:k),w=S.y+(~(y[1]||y[0]).indexOf("%")?w/100*S.height:w)),i||i!==!1&&a.smooth?(v=k-c,b=w-d,a.xOffset=p+(v*f+b*h)-v,a.yOffset=g+(v*m+b*_)-b):a.xOffset=a.yOffset=0,a.xOrigin=k,a.yOrigin=w,a.smooth=!!i,a.origin=t,a.originIsAbsolute=!!r,e.style[le]="0px 0px",s&&($e(s,a,"xOrigin",c,k),$e(s,a,"yOrigin",d,w),$e(s,a,"xOffset",p,a.xOffset),$e(s,a,"yOffset",g,a.yOffset)),e.setAttribute("data-svg-origin",k+" "+w)},Nt=function(e,t){var r=e._gsap||new fn(e);if("x"in r&&!t&&!r.uncache)return r;var i=e.style,n=r.scaleX<0,s="px",a="deg",l=getComputedStyle(e),c=ge(e,le)||"0",d,p,g,f,m,h,_,v,b,y,k,w,S,T,j,C,M,O,P,D,E,L,W,B,K,je,Ce,Ee,ye,Fe,ke,ze;return d=p=g=h=_=v=b=y=k=0,f=m=1,r.svg=!!(e.getCTM&&Mn(e)),l.translate&&((l.translate!=="none"||l.scale!=="none"||l.rotate!=="none")&&(i[U]=(l.translate!=="none"?"translate3d("+(l.translate+" 0 0").split(" ").slice(0,3).join(", ")+") ":"")+(l.rotate!=="none"?"rotate("+l.rotate+") ":"")+(l.scale!=="none"?"scale("+l.scale.split(" ").join(",")+") ":"")+(l[U]!=="none"?l[U]:"")),i.scale=i.rotate=i.translate="none"),T=Qr(e,r.svg),r.svg&&(r.uncache?(K=e.getBBox(),c=r.xOrigin-K.x+"px "+(r.yOrigin-K.y)+"px",B=""):B=!t&&e.getAttribute("data-svg-origin"),Or(e,B||c,!!B||r.originIsAbsolute,r.smooth!==!1,T)),w=r.xOrigin||0,S=r.yOrigin||0,T!==Pt&&(O=T[0],P=T[1],D=T[2],E=T[3],d=L=T[4],p=W=T[5],T.length===6?(f=Math.sqrt(O*O+P*P),m=Math.sqrt(E*E+D*D),h=O||P?nt(P,O)*Qe:0,b=D||E?nt(D,E)*Qe+h:0,b&&(m*=Math.abs(Math.cos(b*ct))),r.svg&&(d-=w-(w*O+S*D),p-=S-(w*P+S*E))):(ze=T[6],Fe=T[7],Ce=T[8],Ee=T[9],ye=T[10],ke=T[11],d=T[12],p=T[13],g=T[14],j=nt(ze,ye),_=j*Qe,j&&(C=Math.cos(-j),M=Math.sin(-j),B=L*C+Ce*M,K=W*C+Ee*M,je=ze*C+ye*M,Ce=L*-M+Ce*C,Ee=W*-M+Ee*C,ye=ze*-M+ye*C,ke=Fe*-M+ke*C,L=B,W=K,ze=je),j=nt(-D,ye),v=j*Qe,j&&(C=Math.cos(-j),M=Math.sin(-j),B=O*C-Ce*M,K=P*C-Ee*M,je=D*C-ye*M,ke=E*M+ke*C,O=B,P=K,D=je),j=nt(P,O),h=j*Qe,j&&(C=Math.cos(j),M=Math.sin(j),B=O*C+P*M,K=L*C+W*M,P=P*C-O*M,W=W*C-L*M,O=B,L=K),_&&Math.abs(_)+Math.abs(h)>359.9&&(_=h=0,v=180-v),f=Y(Math.sqrt(O*O+P*P+D*D)),m=Y(Math.sqrt(W*W+ze*ze)),j=nt(L,W),b=Math.abs(j)>2e-4?j*Qe:0,k=ke?1/(ke<0?-ke:ke):0),r.svg&&(B=e.getAttribute("transform"),r.forceCSS=e.setAttribute("transform","")||!Pn(ge(e,U)),B&&e.setAttribute("transform",B))),Math.abs(b)>90&&Math.abs(b)<270&&(n?(f*=-1,b+=h<=0?180:-180,h+=h<=0?180:-180):(m*=-1,b+=b<=0?180:-180)),t=t||r.uncache,r.x=d-((r.xPercent=d&&(!t&&r.xPercent||(Math.round(e.offsetWidth/2)===Math.round(-d)?-50:0)))?e.offsetWidth*r.xPercent/100:0)+s,r.y=p-((r.yPercent=p&&(!t&&r.yPercent||(Math.round(e.offsetHeight/2)===Math.round(-p)?-50:0)))?e.offsetHeight*r.yPercent/100:0)+s,r.z=g+s,r.scaleX=Y(f),r.scaleY=Y(m),r.rotation=Y(h)+a,r.rotationX=Y(_)+a,r.rotationY=Y(v)+a,r.skewX=b+a,r.skewY=y+a,r.transformPerspective=k+s,(r.zOrigin=parseFloat(c.split(" ")[2])||!t&&r.zOrigin||0)&&(i[le]=Jt(c)),r.xOffset=r.yOffset=0,r.force3D=fe.force3D,r.renderTransform=r.svg?Oa:zn?Nn:Ma,r.uncache=0,r},Jt=function(e){return(e=e.split(" "))[0]+" "+e[1]},gr=function(e,t,r){var i=te(t);return Y(parseFloat(t)+parseFloat(We(e,"x",r+"px",i)))+i},Ma=function(e,t){t.z="0px",t.rotationY=t.rotationX="0deg",t.force3D=0,Nn(e,t)},Xe="0deg",_t="0px",He=") ",Nn=function(e,t){var r=t||this,i=r.xPercent,n=r.yPercent,s=r.x,a=r.y,l=r.z,c=r.rotation,d=r.rotationY,p=r.rotationX,g=r.skewX,f=r.skewY,m=r.scaleX,h=r.scaleY,_=r.transformPerspective,v=r.force3D,b=r.target,y=r.zOrigin,k="",w=v==="auto"&&e&&e!==1||v===!0;if(y&&(p!==Xe||d!==Xe)){var S=parseFloat(d)*ct,T=Math.sin(S),j=Math.cos(S),C;S=parseFloat(p)*ct,C=Math.cos(S),s=gr(b,s,T*C*-y),a=gr(b,a,-Math.sin(S)*-y),l=gr(b,l,j*C*-y+y)}_!==_t&&(k+="perspective("+_+He),(i||n)&&(k+="translate("+i+"%, "+n+"%) "),(w||s!==_t||a!==_t||l!==_t)&&(k+=l!==_t||w?"translate3d("+s+", "+a+", "+l+") ":"translate("+s+", "+a+He),c!==Xe&&(k+="rotate("+c+He),d!==Xe&&(k+="rotateY("+d+He),p!==Xe&&(k+="rotateX("+p+He),(g!==Xe||f!==Xe)&&(k+="skew("+g+", "+f+He),(m!==1||h!==1)&&(k+="scale("+m+", "+h+He),b.style[U]=k||"translate(0, 0)"},Oa=function(e,t){var r=t||this,i=r.xPercent,n=r.yPercent,s=r.x,a=r.y,l=r.rotation,c=r.skewX,d=r.skewY,p=r.scaleX,g=r.scaleY,f=r.target,m=r.xOrigin,h=r.yOrigin,_=r.xOffset,v=r.yOffset,b=r.forceCSS,y=parseFloat(s),k=parseFloat(a),w,S,T,j,C;l=parseFloat(l),c=parseFloat(c),d=parseFloat(d),d&&(d=parseFloat(d),c+=d,l+=d),l||c?(l*=ct,c*=ct,w=Math.cos(l)*p,S=Math.sin(l)*p,T=Math.sin(l-c)*-g,j=Math.cos(l-c)*g,c&&(d*=ct,C=Math.tan(c-d),C=Math.sqrt(1+C*C),T*=C,j*=C,d&&(C=Math.tan(d),C=Math.sqrt(1+C*C),w*=C,S*=C)),w=Y(w),S=Y(S),T=Y(T),j=Y(j)):(w=p,j=g,S=T=0),(y&&!~(s+"").indexOf("px")||k&&!~(a+"").indexOf("px"))&&(y=We(f,"x",s,"px"),k=We(f,"y",a,"px")),(m||h||_||v)&&(y=Y(y+m-(m*w+h*T)+_),k=Y(k+h-(m*S+h*j)+v)),(i||n)&&(C=f.getBBox(),y=Y(y+i/100*C.width),k=Y(k+n/100*C.height)),C="matrix("+w+","+S+","+T+","+j+","+y+","+k+")",f.setAttribute("transform",C),b&&(f.style[U]=C)},Pa=function(e,t,r,i,n){var s=360,a=Q(n),l=parseFloat(n)*(a&&~n.indexOf("rad")?Qe:1),c=l-i,d=i+c+"deg",p,g;return a&&(p=n.split("_")[1],p==="short"&&(c%=s,c!==c%(s/2)&&(c+=c<0?s:-s)),p==="cw"&&c<0?c=(c+s*yi)%s-~~(c/s)*s:p==="ccw"&&c>0&&(c=(c-s*yi)%s-~~(c/s)*s)),e._pt=g=new oe(e._pt,t,r,i,c,pa),g.e=d,g.u="deg",e._props.push(r),g},Mi=function(e,t){for(var r in t)e[r]=t[r];return e},Na=function(e,t,r){var i=Mi({},r._gsap),n="perspective,force3D,transformOrigin,svgOrigin",s=r.style,a,l,c,d,p,g,f,m;i.svg?(c=r.getAttribute("transform"),r.setAttribute("transform",""),s[U]=t,a=Nt(r,1),qe(r,U),r.setAttribute("transform",c)):(c=getComputedStyle(r)[U],s[U]=t,a=Nt(r,1),s[U]=c);for(l in Re)c=i[l],d=a[l],c!==d&&n.indexOf(l)<0&&(f=te(c),m=te(d),p=f!==m?We(r,l,c,m):parseFloat(c),g=parseFloat(d),e._pt=new oe(e._pt,a,l,p,g-p,zr),e._pt.u=m||0,e._props.push(l));Mi(a,i)};ae("padding,margin,Width,Radius",function(o,e){var t="Top",r="Right",i="Bottom",n="Left",s=(e<3?[t,r,i,n]:[t+n,t+r,i+r,i+n]).map(function(a){return e<2?o+a:"border"+a+o});Zt[e>1?"border"+o:o]=function(a,l,c,d,p){var g,f;if(arguments.length<4)return g=s.map(function(m){return De(a,m,c)}),f=g.join(" "),f.split(g[0]).length===5?g[0]:f;g=(d+"").split(" "),f={},s.forEach(function(m,h){return f[m]=g[h]=g[h]||g[(h-1)/2|0]}),a.init(l,f,p)}});var Dn={name:"css",register:Mr,targetTest:function(e){return e.style&&e.nodeType},init:function(e,t,r,i,n){var s=this._props,a=e.style,l=r.vars.startAt,c,d,p,g,f,m,h,_,v,b,y,k,w,S,T,j,C;Hr||Mr(),this.styles=this.styles||Cn(e),j=this.styles.props,this.tween=r;for(h in t)if(h!=="autoRound"&&(d=t[h],!(ue[h]&&mn(h,t,r,i,e,n)))){if(f=typeof d,m=Zt[h],f==="function"&&(d=d.call(r,i,e,n),f=typeof d),f==="string"&&~d.indexOf("random(")&&(d=zt(d)),m)m(this,e,h,d,r)&&(T=1);else if(h.substr(0,2)==="--")c=(getComputedStyle(e).getPropertyValue(h)+"").trim(),d+="",Ie.lastIndex=0,Ie.test(c)||(_=te(c),v=te(d),v?_!==v&&(c=We(e,h,c,v)+v):_&&(d+=_)),this.add(a,"setProperty",c,d,i,n,0,0,h),s.push(h),j.push(h,0,a[h]);else if(f!=="undefined"){if(l&&h in l?(c=typeof l[h]=="function"?l[h].call(r,i,e,n):l[h],Q(c)&&~c.indexOf("random(")&&(c=zt(c)),te(c+"")||c==="auto"||(c+=fe.units[h]||te(De(e,h))||""),(c+"").charAt(1)==="="&&(c=De(e,h))):c=De(e,h),g=parseFloat(c),b=f==="string"&&d.charAt(1)==="="&&d.substr(0,2),b&&(d=d.substr(2)),p=parseFloat(d),h in Oe&&(h==="autoAlpha"&&(g===1&&De(e,"visibility")==="hidden"&&p&&(g=0),j.push("visibility",0,a.visibility),$e(this,a,"visibility",g?"inherit":"hidden",p?"inherit":"hidden",!p)),h!=="scale"&&h!=="transform"&&(h=Oe[h],~h.indexOf(",")&&(h=h.split(",")[0]))),y=h in Re,y){if(this.styles.save(h),C=d,f==="string"&&d.substring(0,6)==="var(--"){if(d=ge(e,d.substring(4,d.indexOf(")"))),d.substring(0,5)==="calc("){var M=e.style.perspective;e.style.perspective=d,d=ge(e,"perspective"),M?e.style.perspective=M:qe(e,"perspective")}p=parseFloat(d)}if(k||(w=e._gsap,w.renderTransform&&!t.parseTransform||Nt(e,t.parseTransform),S=t.smoothOrigin!==!1&&w.smooth,k=this._pt=new oe(this._pt,a,U,0,1,w.renderTransform,w,0,-1),k.dep=1),h==="scale")this._pt=new oe(this._pt,w,"scaleY",w.scaleY,(b?ot(w.scaleY,b+p):p)-w.scaleY||0,zr),this._pt.u=0,s.push("scaleY",h),h+="X";else if(h==="transformOrigin"){j.push(le,0,a[le]),d=za(d),w.svg?Or(e,d,0,S,0,this):(v=parseFloat(d.split(" ")[2])||0,v!==w.zOrigin&&$e(this,w,"zOrigin",w.zOrigin,v),$e(this,a,h,Jt(c),Jt(d)));continue}else if(h==="svgOrigin"){Or(e,d,1,S,0,this);continue}else if(h in On){Pa(this,w,h,g,b?ot(g,b+d):d);continue}else if(h==="smoothOrigin"){$e(this,w,"smooth",w.smooth,d);continue}else if(h==="force3D"){w[h]=d;continue}else if(h==="transform"){Na(this,d,e);continue}}else h in a||(h=gt(h)||h);if(y||(p||p===0)&&(g||g===0)&&!ha.test(d)&&h in a)_=(c+"").substr((g+"").length),p||(p=0),v=te(d)||(h in fe.units?fe.units[h]:_),_!==v&&(g=We(e,h,c,v)),this._pt=new oe(this._pt,y?w:a,h,g,(b?ot(g,b+p):p)-g,!y&&(v==="px"||h==="zIndex")&&t.autoRound!==!1?ma:zr),this._pt.u=v||0,y&&C!==d?(this._pt.b=c,this._pt.e=C,this._pt.r=fa):_!==v&&v!=="%"&&(this._pt.b=c,this._pt.r=ga);else if(h in a)Ca.call(this,e,h,c,b?b+d:d);else if(h in e)this.add(e,h,c||e[h],b?b+d:d,i,n);else if(h!=="parseTransform"){Lr(h,d);continue}y||(h in a?j.push(h,0,a[h]):typeof e[h]=="function"?j.push(h,2,e[h]()):j.push(h,1,c||e[h])),s.push(h)}}T&&bn(this)},render:function(e,t){if(t.tween._time||!Gr())for(var r=t._pt;r;)r.r(e,r.d),r=r._next;else t.styles.revert()},get:De,aliases:Oe,getSetter:function(e,t,r){var i=Oe[t];return i&&i.indexOf(",")<0&&(t=i),t in Re&&t!==le&&(e._gsap.x||De(e,"x"))?r&&bi===r?t==="scale"?va:wa:(bi=r||{})&&(t==="scale"?ba:ya):e.style&&!Rr(e.style[t])?_a:~t.indexOf("-")?xa:Yr(e,t)},core:{_removeProperty:qe,_getMatrix:Qr}};ce.utils.checkPrefix=gt;ce.core.getStyleSaver=Cn;(function(o,e,t,r){var i=ae(o+","+e+","+t,function(n){Re[n]=1});ae(e,function(n){fe.units[n]="deg",On[n]=1}),Oe[i[13]]=o+","+e,ae(r,function(n){var s=n.split(":");Oe[s[1]]=i[s[0]]})})("x,y,z,scale,scaleX,scaleY,xPercent,yPercent","rotation,rotationX,rotationY,skewX,skewY","transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective","0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY");ae("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective",function(o){fe.units[o]="px"});ce.registerPlugin(Dn);var Dt=ce.registerPlugin(Dn)||ce;Dt.core.Tween;/*!
 * @gsap/react 2.1.2
 * https://gsap.com
 *
 * Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license or for
 * Club GSAP members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
*/let Oi=typeof document!="undefined"?A.useLayoutEffect:A.useEffect,Pi=o=>o&&!Array.isArray(o)&&typeof o=="object",$t=[],Da={},An=Dt;const ir=(o,e=$t)=>{let t=Da;Pi(o)?(t=o,o=null,e="dependencies"in t?t.dependencies:$t):Pi(e)&&(t=e,e="dependencies"in t?t.dependencies:$t),o&&typeof o!="function"&&console.warn("First parameter must be a function or config object");const{scope:r,revertOnUpdate:i}=t,n=A.useRef(!1),s=A.useRef(An.context(()=>{},r)),a=A.useRef(c=>s.current.add(null,c)),l=e&&e.length&&!i;return l&&Oi(()=>(n.current=!0,()=>s.current.revert()),$t),Oi(()=>{if(o&&s.current.add(o,r),!l||!n.current)return()=>s.current.revert()},e),{context:s.current,contextSafe:a.current}};ir.register=o=>{An=o};ir.headless=!0;/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Aa=o=>o==null?void 0:o.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */function Ra(o,e,t=[]){if(e==null)throw new Error("[lucide]: iconNode is required when icon name is used");return{name:Aa(o),size:24,node:e,...t.length>0?{aliases:t}:{}}}/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ea=o=>{let e="",t=!1;for(const r of o){if(r==="-"||r==="_"||r<=" "){t=e.length>0;continue}e.length===0?e+=r.toLowerCase():e+=t?r.toUpperCase():r,t=!1}return e};/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Fa=o=>{const e=Ea(o);return e.charAt(0).toUpperCase()+e.slice(1)};/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Pr=(...o)=>o.filter((e,t,r)=>!!e&&e.trim()!==""&&r.indexOf(e)===t).join(" ").trim();/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ge={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */function fr(o){return o!=null}function La(o,e={}){var g,f,m,h,_,v,b,y,k,w,S,T,j,C,M;const t=(g=e.attributeNames)!=null?g:{},r=O=>{var P;return(P=t[O])!=null?P:O},i=(m=(f=o.size)!=null?f:o.width)!=null?m:Ge.width,n=(_=(h=o.size)!=null?h:o.height)!=null?_:Ge.height,s=(b=(v=o.aliases)==null?void 0:v.filter(O=>typeof O=="string"&&O.trim()!=="").map(O=>`lucide-${O}`))!=null?b:[],a=[...o.name?[`lucide-${o.name}`]:[],...s],l=(k=(y=e.className)==null?void 0:y.split(" ").filter(Boolean))!=null?k:[],c=e.includeDefaultClasses===!1?Pr(...l):Pr("lucide",...a,...l),d=e.absoluteStrokeWidth?Number((w=e.strokeWidth)!=null?w:Ge["stroke-width"])*Number((T=(S=o.size)!=null?S:o.width)!=null?T:Ge.width)/Number((C=(j=e.size)!=null?j:e.width)!=null?C:Ge.width):(M=e.strokeWidth)!=null?M:Ge["stroke-width"];return["svg",{...Object.entries(Ge).reduce((O,[P,D])=>(O[r(P)]=D,O),{}),..."color"in e&&e.color&&{[r("stroke")]:e.color},..."size"in e&&fr(e.size)&&{[r("width")]:e.size,[r("height")]:e.size},..."width"in e&&fr(e.width)&&{[r("width")]:e.width},..."height"in e&&fr(e.height)&&{[r("height")]:e.height},[r("stroke-width")]:d,...c&&{[r("class")]:c},[r("viewBox")]:`0 0 ${i} ${n}`,...e.hasA11yProp===!1?{[r("aria-hidden")]:"true"}:{},..."attributes"in e&&e.attributes},o.node.map(O=>{const[P,D,E]=O,L=e.nonScalingStroke?{[r("vector-effect")]:"non-scaling-stroke",...D}:D;return E?[P,L,E]:[P,L]})]}/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */function Ba(o,e={}){return La(o,{...e,attributeNames:{...e.attributeNames,class:"className","stroke-width":"strokeWidth","stroke-linecap":"strokeLinecap","stroke-linejoin":"strokeLinejoin","vector-effect":"vectorEffect"}})}/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $a=o=>{for(const e in o)if(e.startsWith("aria-")||e==="role"||e==="title")return!0;return!1},Va=A.createContext({}),Ia=()=>A.useContext(Va),Ua=A.forwardRef(({color:o,size:e,width:t,height:r,strokeWidth:i,absoluteStrokeWidth:n,nonScalingStroke:s,className:a="",children:l,iconNode:c=[],icon:d={node:c,aliases:[],size:24},...p},g)=>{var T,j,C;const{size:f=24,strokeWidth:m=2,absoluteStrokeWidth:h=!1,nonScalingStroke:_=!1,color:v="currentColor",className:b=""}=(T=Ia())!=null?T:{},y=!!l||$a(p),[k,w,S=[]]=Ba(d,{color:o!=null?o:v,width:(j=t!=null?t:e)!=null?j:f,height:(C=r!=null?r:e)!=null?C:f,strokeWidth:i!=null?i:m,absoluteStrokeWidth:n!=null?n:h,nonScalingStroke:s!=null?s:_,className:Pr(b,a),hasA11yProp:y,attributes:p});return A.createElement(k,{ref:g,...w},[...S.map(([M,O])=>A.createElement(M,O)),...Array.isArray(l)?l:[l]])});/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */function X(o,e=[],t=[]){const r=typeof o=="string"?Ra(o,e,t):o,i=A.forwardRef(({className:n,...s},a)=>A.createElement(Ua,{ref:a,icon:r,className:n,...s}));return r.name&&(i.displayName=Fa(r.name)),i}/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Rn={name:"arrow-down-left",size:24,node:[["path",{d:"M17 7 7 17",key:"15tmo1"}],["path",{d:"M17 17H7V7",key:"1org7z"}]]};Rn.node;const En=X(Rn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Fn={name:"arrow-right",size:24,node:[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]]};Fn.node;const qa=X(Fn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ln={name:"arrow-up-right",size:24,node:[["path",{d:"M7 7h10v10",key:"1tivn9"}],["path",{d:"M7 17 17 7",key:"1vkiza"}]]};Ln.node;const Ni=X(Ln);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Bn={name:"bell",size:24,node:[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0",key:"vwvbt9"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",key:"11g9vi"}]]};Bn.node;const Wa=X(Bn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $n={name:"building-complex",size:24,node:[["path",{d:"M10 12h4",key:"a56b0p"}],["path",{d:"M10 8h4",key:"1sr2af"}],["path",{d:"M14 21v-3a2 2 0 0 0-4 0v3",key:"1rgiei"}],["path",{d:"M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2",key:"secmi2"}],["path",{d:"M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16",key:"16ra0t"}]],aliases:["building-2"]};$n.node;const Ya=X($n);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Vn={name:"chart-no-axes-combined",size:24,node:[["path",{d:"M12 16v5",key:"zza2cw"}],["path",{d:"M16 14.639V21",key:"1s85h0"}],["path",{d:"M20 10.656V21",key:"q45596"}],["path",{d:"m22 3-8.646 8.646a.5.5 0 0 1-.708 0L9.354 8.354a.5.5 0 0 0-.707 0L2 15",key:"1fw8x9"}],["path",{d:"M4 18.463V21",key:"1otddq"}],["path",{d:"M8 14.656V21",key:"1t2idw"}]]};Vn.node;const Nr=X(Vn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const In={name:"check",size:24,node:[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]};In.node;const mr=X(In);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Un={name:"coffee",size:24,node:[["path",{d:"M10 2v2",key:"7u0qdc"}],["path",{d:"M14 2v2",key:"6buw04"}],["path",{d:"M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1",key:"pwadti"}],["path",{d:"M6 2v2",key:"colzsn"}]]};Un.node;const Xa=X(Un);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qn={name:"credit-card",size:24,node:[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}],["path",{d:"M6 14h2",key:"mk7k0u"}]]};qn.node;const Ha=X(qn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Wn={name:"download",size:24,node:[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]]};Wn.node;const Ga=X(Wn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Yn={name:"house",size:24,node:[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"r6nss1"}]],aliases:["home"]};Yn.node;const Ka=X(Yn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xn={name:"layers",size:24,node:[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]],aliases:["layers-3"]};Xn.node;const Di=X(Xn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Hn={name:"moon",size:24,node:[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",key:"kfwtm"}]]};Hn.node;const Qa=X(Hn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gn={name:"plane",size:24,node:[["path",{d:"M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z",key:"1v9wt8"}]]};Gn.node;const Kn=X(Gn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qn={name:"search",size:24,node:[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]]};Qn.node;const Ai=X(Qn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zn={name:"settings-2",size:24,node:[["path",{d:"M14 17H5",key:"gfn3mx"}],["path",{d:"M19 7h-9",key:"6i9tg"}],["circle",{cx:"17",cy:"17",r:"3",key:"18b49y"}],["circle",{cx:"7",cy:"7",r:"3",key:"dfmy0x"}]]};Zn.node;const Ri=X(Zn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Jn={name:"shopping-bag",size:24,node:[["path",{d:"M16 10a4 4 0 0 1-8 0",key:"1ltviw"}],["path",{d:"M3.103 6.034h17.794",key:"awc11p"}],["path",{d:"M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",key:"o988cm"}]]};Jn.node;const Za=X(Jn);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const es={name:"sun",size:24,node:[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]]};es.node;const Ja=X(es);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ts={name:"target",size:24,node:[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]]};ts.node;const Dr=X(ts);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rs={name:"wallet",size:24,node:[["path",{d:"M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",key:"18etb6"}],["path",{d:"M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4",key:"xoc0q4"}]]};rs.node;const is=X(rs);/**
 * @license lucide-react v1.70.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ns={name:"x",size:24,node:[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]};ns.node;const _r=X(ns);Dt.registerPlugin(ir);const Te={blur:22,opacity:.3,saturation:1.2,tint:"#ffffff",edge:.6},Ei=[{id:"overview",label:"Visão geral",icon:Ka},{id:"activity",label:"Atividade",icon:is},{id:"savings",label:"Metas",icon:Dr},{id:"reports",label:"Relatórios",icon:Nr}],vt=(o,e,t,r)=>Number.isFinite(o)?Math.min(t,Math.max(e,o)):r,Vt=o=>{var e,t,r,i,n;return{blur:vt((e=o.blur)!=null?e:Te.blur,0,40,Te.blur),opacity:vt((t=o.opacity)!=null?t:Te.opacity,.08,.9,Te.opacity),saturation:vt((r=o.saturation)!=null?r:Te.saturation,.5,2,Te.saturation),edge:vt((i=o.edge)!=null?i:Te.edge,0,1,Te.edge),tint:/^#[0-9a-f]{6}$/i.test((n=o.tint)!=null?n:"")?o.tint:Te.tint}},Ke=o=>Number.isFinite(o)?Math.max(0,o):0,xr=o=>o.target>0?vt(o.saved/o.target*100,0,100,0):0;function Fi({category:o}){const e=o==="Receita"?En:o==="Alimentação"?Xa:o==="Viagem"?Kn:o==="Marketing"?Za:Ya;return u.jsx(e,{size:17,strokeWidth:1.7,"aria-hidden":"true"})}function eo({brand:o="Workspace",userName:e,backgroundImage:t,balance:r=0,balanceChange:i,account:n,periodLabel:s,cashFlowPeriods:a=[],initialPeriodId:l,footerNote:c,savingsNote:d,transactions:p=[],goals:g=[],glass:f=Te,onGlassChange:m,currency:h="BRL",theme:_="system",useHostTheme:v=!0,className:b="",style:y}){var si,ai,oi,li,ci;const k=A.useRef(null),w=A.useRef(null),S=A.useRef(null),T=A.useId().replace(/:/g,""),[j,C]=A.useState("overview"),[M,O]=A.useState(()=>Vt(f)),[P,D]=A.useState(!1),[E,L]=A.useState(_),[W,B]=A.useState((ai=l!=null?l:(si=a[0])==null?void 0:si.id)!=null?ai:""),[K,je]=A.useState(""),[Ce,Ee]=A.useState(""),[ye,Fe]=A.useState(!1),[ke,ze]=A.useState(!1);A.useEffect(()=>O(Vt(f)),[f.blur,f.opacity,f.saturation,f.tint,f.edge]),A.useEffect(()=>L(_),[_]),A.useEffect(()=>{l!==void 0&&B(l)},[l]),A.useEffect(()=>{var x,z;P&&((z=(x=k.current)==null?void 0:x.querySelector(".gw-material button"))==null||z.focus())},[P]),A.useEffect(()=>ze(!1),[t]),A.useEffect(()=>{if(!Ce)return;const x=window.setTimeout(()=>Ee(""),3200);return()=>window.clearTimeout(x)},[Ce]);const ss=A.useMemo(()=>{try{return new Intl.NumberFormat("pt-BR",{style:"currency",currency:h,maximumFractionDigits:2})}catch{return new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"})}},[h]),J=x=>ss.format(Number.isFinite(x)?x:0),Zr=p.filter(x=>x.amount<0).reduce((x,z)=>x-z.amount,0),as=g.reduce((x,z)=>x+Math.max(0,z.saved),0),nr=p.filter(x=>`${x.name} ${x.category}`.toLowerCase().includes(K.toLowerCase())),ee=(oi=a.find(x=>x.id===W))!=null?oi:a[0],H=(li=ee==null?void 0:ee.points)!=null?li:[],Rt=H.reduce((x,z)=>x+Ke(z.income),0),Et=H.reduce((x,z)=>x+Ke(z.expenses),0),sr=Math.max(1,...H.flatMap(x=>[Ke(x.income),Ke(x.expenses)])),ft=x=>H.length===1?300:x*600/(H.length-1),Ft=x=>180-Ke(x)/sr*160,Jr=x=>H.map((z,xe)=>`${ft(xe)},${Ft(z[x])}`).join(" "),os=new Set(Array.from({length:Math.min(H.length,6)},(x,z)=>H.length<=6?z:Math.round(z*(H.length-1)/5))),ls=Array.from(new Set(p.filter(x=>x.amount<0).map(x=>x.category)));ir(()=>{const x=Dt.matchMedia();return x.add("(prefers-reduced-motion: no-preference)",()=>{var xe;const z=(xe=w.current)==null?void 0:xe.querySelectorAll(".gw-reveal");z!=null&&z.length&&Dt.fromTo(z,{y:12,opacity:.45,filter:"blur(3px)"},{y:0,opacity:1,filter:"blur(0px)",duration:.48,stagger:.045,ease:"power3.out",clearProps:"transform,opacity,filter"})}),()=>x.revert()},{scope:k,dependencies:[j],revertOnUpdate:!0});function Lt(x){const z=Vt({...M,...x});O(z),m==null||m(z)}function ei(){var x;D(!1),(x=S.current)==null||x.focus()}function mt(x){C(x),Fe(!1)}function cs(){const x=k.current?getComputedStyle(k.current).colorScheme:"normal",z=x==="dark"||x!=="light"&&window.matchMedia("(prefers-color-scheme: dark)").matches;L(z?"light":"dark")}function ds(){const x=de=>`"${(/^[\s]*[=+@-]/.test(de)?"'":"")+de.replace(/"/g,'""')}"`,z=["Nome,Categoria,Data,Valor,Status",...nr.map(de=>[x(de.name),x(de.category),x(de.date),de.amount,x(de.status)].join(","))].join(`\r
`),xe=URL.createObjectURL(new Blob([z],{type:"text/csv;charset=utf-8;"})),ie=document.createElement("a");ie.href=xe,ie.download="transacoes.csv",ie.click(),window.setTimeout(()=>URL.revokeObjectURL(xe),1e3),Ee("Transações exportadas.")}const ar=(x=!1)=>u.jsx("nav",{className:x?"gw-rail gw-glass":"gw-dock gw-glass","aria-label":x?"Navegação rápida":"Seções do painel",children:Ei.map((z,xe)=>u.jsxs("button",{type:"button","aria-label":x?z.label:void 0,title:x?z.label:void 0,"aria-current":j===z.id?"page":void 0,onClick:()=>mt(z.id),onKeyDown:ie=>{var di,ui;if(!["ArrowLeft","ArrowRight","Home","End"].includes(ie.key))return;ie.preventDefault();const de=ie.key==="Home"?0:ie.key==="End"?3:(xe+(ie.key==="ArrowRight"?1:3))%4;mt(Ei[de].id),(ui=(di=ie.currentTarget.parentElement)==null?void 0:di.children[de])==null||ui.focus()},children:[u.jsx(z.icon,{size:18,strokeWidth:1.7,"aria-hidden":"true"}),u.jsx("span",{children:z.label})]},z.id))}),ti=x=>a.length>1?u.jsx("div",{className:"gw-segment",role:"group","aria-label":x,children:a.map(z=>u.jsx("button",{type:"button","aria-pressed":(ee==null?void 0:ee.id)===z.id,onClick:()=>B(z.id),children:z.label},z.id))}):null,ri=H.length?u.jsxs("div",{className:"gw-chart-wrap",children:[u.jsxs("div",{className:"gw-chart-labels",children:[u.jsx("span",{children:J(sr)}),u.jsx("span",{children:J(sr/2)}),u.jsx("span",{children:J(0)})]}),u.jsxs("svg",{viewBox:"0 0 600 185",role:"img","aria-label":`${(ci=ee==null?void 0:ee.label)!=null?ci:"Fluxo de caixa"}: entradas ${J(Rt)}, saídas ${J(Et)}.`,preserveAspectRatio:"none",children:[u.jsx("desc",{children:H.map(x=>`${x.label}: entradas ${J(Ke(x.income))}, saídas ${J(Ke(x.expenses))}`).join(". ")}),u.jsx("defs",{children:u.jsxs("linearGradient",{id:`${T}-area`,x1:"0",x2:"0",y1:"0",y2:"1",children:[u.jsx("stop",{offset:"0",stopColor:"var(--gw-accent)",stopOpacity:".23"}),u.jsx("stop",{offset:"1",stopColor:"var(--gw-accent)",stopOpacity:"0"})]})}),[20,100,180].map(x=>u.jsx("path",{d:`M0 ${x} H600`,stroke:"currentColor",opacity:".11",strokeDasharray:"3 5"},x)),u.jsx("path",{d:`M${ft(0)} 185 ${H.map((x,z)=>`L${ft(z)} ${Ft(x.income)}`).join(" ")} L${ft(H.length-1)} 185 Z`,fill:`url(#${T}-area)`}),u.jsx("polyline",{points:Jr("income"),fill:"none",stroke:"var(--gw-accent)",strokeWidth:"2.6",strokeLinejoin:"round",strokeLinecap:"round"}),u.jsx("polyline",{points:Jr("expenses"),fill:"none",stroke:"currentColor",strokeOpacity:".45",strokeWidth:"2",strokeLinejoin:"round",strokeLinecap:"round"}),H.length===1&&u.jsxs(u.Fragment,{children:[u.jsx("circle",{cx:"300",cy:Ft(H[0].income),r:"4",fill:"var(--gw-accent)"}),u.jsx("circle",{cx:"300",cy:Ft(H[0].expenses),r:"4",fill:"currentColor",opacity:".45"})]})]}),u.jsx("div",{className:"gw-chart-months",children:H.map((x,z)=>os.has(z)&&u.jsx("span",{style:{left:`${ft(z)/6}%`,transform:z===0&&H.length>1?"none":z===H.length-1&&H.length>1?"translateX(-100%)":"translateX(-50%)"},children:x.label},`${x.label}-${z}`))})]}):u.jsxs("div",{className:"gw-empty gw-chart-empty",children:[u.jsx(Nr,{size:23,"aria-hidden":"true"}),u.jsx("h3",{children:"Sem dados de fluxo de caixa"}),u.jsx("p",{children:"O fluxo aparecerá quando houver dados do período."})]}),ii=x=>u.jsx("div",{className:"gw-transactions",children:nr.length?nr.slice(0,x).map(z=>u.jsxs("div",{className:"gw-transaction",children:[u.jsx("span",{className:`gw-transaction-icon ${z.amount>0?"is-income":""}`,children:u.jsx(Fi,{category:z.category})}),u.jsxs("div",{className:"gw-transaction-name",children:[u.jsx("strong",{children:z.name}),u.jsxs("span",{children:[z.category," · ",z.date]})]}),u.jsxs("span",{className:`gw-transaction-status ${z.status==="Pending"?"is-pending":""}`,children:[z.status==="Completed"&&u.jsx(mr,{size:12,"aria-hidden":"true"}),z.status==="Completed"?"Concluído":"Pendente"]}),u.jsxs("strong",{className:z.amount>0?"gw-positive":"",children:[z.amount>0?"+":"−",J(Math.abs(z.amount))]})]},z.id)):u.jsxs("div",{className:"gw-empty",children:[u.jsx(Ai,{size:23,"aria-hidden":"true"}),u.jsx("h3",{children:K?"Nenhuma transação encontrada":"Nenhuma transação ainda"}),u.jsx("p",{children:K?"Tente outro nome ou categoria.":"Sua atividade aparecerá aqui."}),K&&u.jsx("button",{type:"button",onClick:()=>je(""),children:"Limpar busca"})]})}),ni=u.jsx("div",{className:"gw-goals",children:g.length?g.map((x,z)=>u.jsxs("div",{className:"gw-goal",children:[u.jsxs("div",{className:"gw-goal-top",children:[u.jsx("span",{className:"gw-goal-icon",children:z%2?u.jsx(Kn,{size:18,"aria-hidden":"true"}):u.jsx(Dr,{size:18,"aria-hidden":"true"})}),u.jsx("strong",{children:x.name}),u.jsxs("span",{children:[Math.round(xr(x)),"%"]})]}),u.jsx("div",{className:"gw-goal-track",role:"progressbar","aria-label":x.name,"aria-valuenow":Math.round(xr(x)),"aria-valuemin":0,"aria-valuemax":100,children:u.jsx("i",{style:{width:`${xr(x)}%`,background:x.color}})}),u.jsxs("p",{children:[u.jsx("strong",{children:J(x.saved)}),u.jsxs("span",{children:["de ",J(x.target)]})]})]},x.id)):u.jsx("p",{className:"gw-empty",children:"Nenhuma meta cadastrada."})});return u.jsxs("div",{ref:k,className:`gw-root ${b}`,"data-theme":v?"system":E,"data-host-theme":v,style:{"--gw-blur":`${M.blur}px`,"--gw-opacity":M.opacity,"--gw-saturation":M.saturation,"--gw-tint":v?`color-mix(in srgb, var(--color-background, Canvas) 80%, ${M.tint})`:M.tint,"--gw-edge":M.edge,...y},onKeyDown:x=>{x.key==="Escape"&&(P&&ei(),Fe(!1))},children:[u.jsx("style",{children:to}),t&&!ke&&u.jsx("img",{className:"gw-room",src:t,alt:"",onError:()=>ze(!0)}),u.jsx("div",{className:"gw-room-shade","aria-hidden":"true"}),u.jsxs("div",{className:"gw-workspace",children:[u.jsxs("header",{className:"gw-topbar gw-glass",children:[u.jsxs("a",{className:"gw-brand",href:"#",onClick:x=>{x.preventDefault(),mt("overview")},children:[u.jsx("span",{className:"gw-brand-icon",children:u.jsx(Di,{size:18,strokeWidth:1.7,"aria-hidden":"true"})}),u.jsx("strong",{children:o}),u.jsx("span",{className:"gw-brand-divider"}),u.jsx("span",{className:"gw-personal",children:"Painel de demonstração"})]}),u.jsxs("div",{className:"gw-toolbar",children:[u.jsxs("button",{type:"button",className:"gw-adjust",ref:S,onClick:()=>{D(!P),Fe(!1)},"aria-expanded":P,"aria-controls":`${T}-material`,children:[u.jsx(Ri,{size:16,"aria-hidden":"true"}),u.jsx("span",{children:"Ajustar vidro"})]}),!v&&u.jsxs("button",{type:"button",className:"gw-icon-button","aria-label":"Alternar tema claro e escuro",onClick:cs,children:[u.jsx(Ja,{className:"gw-sun",size:17,"aria-hidden":"true"}),u.jsx(Qa,{className:"gw-moon",size:17,"aria-hidden":"true"})]}),u.jsxs("button",{type:"button",className:"gw-icon-button gw-bell","aria-label":"Notificações","aria-expanded":ye,onClick:()=>{Fe(!ye),D(!1)},children:[u.jsx(Wa,{size:17,"aria-hidden":"true"}),u.jsx("i",{})]}),e&&u.jsx("span",{className:"gw-avatar",title:e,children:e.slice(0,1).toUpperCase()})]})]}),u.jsxs("div",{className:"gw-stage",children:[ar(!0),u.jsxs("main",{className:"gw-main gw-glass",children:[u.jsxs("div",{className:"gw-view-heading",children:[u.jsxs("div",{children:[u.jsx("p",{className:"gw-greeting",children:j==="overview"&&e?`Bem-vindo de volta, ${e}.`:"Painel comercial"}),u.jsx("h1",{children:j==="overview"?"Visão geral":j==="activity"?"Atividade":j==="savings"?"Metas":"Relatórios"})]}),u.jsx("div",{className:"gw-heading-action",children:j==="activity"||j==="reports"?u.jsxs("button",{type:"button",className:"gw-button",onClick:ds,children:[u.jsx(Ga,{size:14,"aria-hidden":"true"}),"Exportar CSV"]}):s&&u.jsx("span",{className:"gw-date",children:s})})]}),u.jsx("div",{className:"gw-mobile-nav",children:ar()}),u.jsxs("div",{ref:w,className:"gw-view",children:[j==="overview"&&u.jsxs(u.Fragment,{children:[u.jsxs("div",{className:"gw-overview-grid",children:[u.jsxs("section",{className:"gw-panel gw-balance gw-reveal",children:[u.jsxs("div",{className:"gw-panel-title",children:[u.jsx("span",{children:"Saldo disponível"}),u.jsx(is,{size:17,"aria-hidden":"true"})]}),u.jsx("strong",{className:"gw-balance-value",children:J(r)}),i&&Number.isFinite(i.percent)&&u.jsxs("p",{className:"gw-balance-meta",children:[u.jsxs("span",{className:i.percent>=0?"gw-positive":void 0,children:[i.percent>0?"+":"",i.percent.toLocaleString("pt-BR"),"%"]})," ",i.label]}),n&&u.jsxs("div",{className:"gw-account",children:[u.jsx("span",{className:"gw-account-icon",children:u.jsx(Ha,{size:19,"aria-hidden":"true"})}),u.jsxs("div",{children:[u.jsx("strong",{children:n.name}),n.lastFour&&u.jsxs("span",{children:["•••• ",n.lastFour.slice(-4)]})]}),u.jsx("button",{type:"button","aria-label":"Ver atividade da conta",onClick:()=>mt("activity"),children:u.jsx(Ni,{size:20,"aria-hidden":"true"})})]})]}),u.jsxs("section",{className:"gw-panel gw-cashflow gw-reveal",children:[u.jsxs("div",{className:"gw-panel-title",children:[u.jsx("h2",{children:"Fluxo de caixa"}),ti("Período do gráfico")]}),u.jsxs("div",{className:"gw-chart-summary",children:[u.jsxs("div",{children:[u.jsxs("span",{children:[u.jsx("i",{}),"Entradas"]}),u.jsx("strong",{children:J(Rt)})]}),u.jsxs("div",{children:[u.jsxs("span",{children:[u.jsx("i",{}),"Saídas"]}),u.jsx("strong",{children:J(Et)})]})]}),ri]})]}),u.jsxs("div",{className:"gw-lower-grid",children:[u.jsxs("section",{className:"gw-panel gw-reveal",children:[u.jsxs("div",{className:"gw-panel-title",children:[u.jsx("h2",{children:"Atividade recente"}),u.jsxs("button",{className:"gw-text-button",type:"button",onClick:()=>mt("activity"),children:["Ver tudo",u.jsx(qa,{size:14,"aria-hidden":"true"})]})]}),ii(4)]}),u.jsxs("section",{className:"gw-panel gw-reveal",children:[u.jsxs("div",{className:"gw-panel-title",children:[u.jsx("h2",{children:"Metas"}),u.jsxs("span",{className:"gw-small-label",children:[g.length," ativas"]})]}),ni]})]})]}),j==="activity"&&u.jsxs("section",{className:"gw-panel gw-reveal",children:[u.jsxs("div",{className:"gw-panel-title",children:[u.jsxs("h2",{children:["Transações"," ",u.jsx("span",{className:"gw-count",children:p.length})]}),u.jsxs("label",{className:"gw-search",children:[u.jsx(Ai,{size:15,"aria-hidden":"true"}),u.jsx("input",{"aria-label":"Buscar transações",placeholder:"Buscar transações",value:K,onChange:x=>je(x.target.value)}),K&&u.jsx("button",{type:"button","aria-label":"Limpar busca",onClick:()=>je(""),children:u.jsx(_r,{size:14,"aria-hidden":"true"})})]})]}),ii()]}),j==="savings"&&u.jsxs(u.Fragment,{children:[u.jsxs("div",{className:"gw-savings-intro gw-reveal",children:[u.jsx("span",{className:"gw-savings-orb",children:u.jsx(Dr,{size:28,strokeWidth:1.3,"aria-hidden":"true"})}),u.jsxs("div",{children:[u.jsx("p",{children:"Total acumulado"}),u.jsx("strong",{children:J(as)})]}),u.jsxs("span",{children:[g.length," metas",u.jsx("br",{}),"Acompanhadas em um só lugar"]})]}),u.jsxs("section",{className:"gw-panel gw-reveal",children:[u.jsxs("div",{className:"gw-panel-title",children:[u.jsx("h2",{children:"Suas metas"}),u.jsxs("span",{children:[g.length," ativas"]})]}),ni]}),d&&u.jsxs("section",{className:"gw-savings-note gw-reveal",children:[u.jsx(mr,{size:18,"aria-hidden":"true"}),u.jsx("p",{children:d})]})]}),j==="reports"&&u.jsxs(u.Fragment,{children:[u.jsx("div",{className:"gw-report-stats gw-reveal",children:[{label:"Entradas",value:Rt,icon:En},{label:"Saídas",value:Et,icon:Ni},{label:"Resultado líquido",value:Rt-Et,icon:Nr}].map(x=>{var z;return u.jsxs("section",{className:"gw-panel",children:[u.jsxs("div",{className:"gw-panel-title",children:[u.jsx("span",{children:x.label}),u.jsx(x.icon,{size:17,"aria-hidden":"true"})]}),u.jsx("strong",{children:J(x.value)}),u.jsx("span",{children:(z=ee==null?void 0:ee.label)!=null?z:"Sem dados do período"})]},x.label)})}),u.jsxs("div",{className:"gw-reports-grid",children:[u.jsxs("section",{className:"gw-panel gw-reveal",children:[u.jsxs("div",{className:"gw-panel-title",children:[u.jsx("h2",{children:"Entradas e saídas"}),ti("Período do relatório")]}),u.jsxs("div",{className:"gw-chart-legend",children:[u.jsxs("span",{children:[u.jsx("i",{}),"Entradas"]}),u.jsxs("span",{children:[u.jsx("i",{}),"Saídas"]})]}),ri,(ee==null?void 0:ee.description)&&u.jsx("p",{className:"gw-chart-footnote",children:ee.description})]}),u.jsxs("section",{className:"gw-panel gw-reveal",children:[u.jsxs("div",{className:"gw-panel-title",children:[u.jsx("h2",{children:"Para onde vai"}),u.jsx("span",{children:"Toda a atividade"})]}),u.jsx("div",{className:"gw-category-list",children:ls.map((x,z)=>{const xe=p.filter(ie=>ie.category===x&&ie.amount<0).reduce((ie,de)=>ie-de.amount,0);return u.jsxs("div",{children:[u.jsxs("div",{children:[u.jsx(Fi,{category:x}),u.jsx("span",{children:x}),u.jsx("strong",{children:J(xe)})]}),u.jsx("span",{className:"gw-category-track",children:u.jsx("i",{style:{width:`${Zr?xe/Zr*100:0}%`,opacity:Math.max(.4,1-z*.14)}})})]},x)})})]})]})]})]},j),c&&u.jsx("footer",{className:"gw-footer",children:u.jsxs("span",{children:[u.jsx("i",{}),c]})}),u.jsx("div",{className:"gw-desktop-dock",children:ar()})]})]}),ye&&u.jsxs("aside",{className:"gw-notifications gw-glass","aria-label":"Notifications",children:[u.jsxs("div",{children:[u.jsx("h2",{children:"Tudo em dia."}),u.jsx("button",{type:"button","aria-label":"Fechar notificações",onClick:()=>Fe(!1),children:u.jsx(_r,{size:17,"aria-hidden":"true"})})]}),u.jsx("p",{children:"Nenhuma notificação nova."})]}),P&&u.jsxs("aside",{className:"gw-material gw-glass",id:`${T}-material`,"aria-label":"Aparência do vidro",children:[u.jsxs("div",{className:"gw-material-title",children:[u.jsxs("div",{children:[u.jsx("span",{className:"gw-material-icon",children:u.jsx(Ri,{size:18,"aria-hidden":"true"})}),u.jsx("h2",{children:"Aparência do vidro"})]}),u.jsx("button",{type:"button",className:"gw-icon-button","aria-label":"Fechar ajustes do vidro",onClick:ei,children:u.jsx(_r,{size:18,"aria-hidden":"true"})})]}),u.jsx("p",{children:"Ajuste o material em todo o painel."}),u.jsxs("div",{className:"gw-material-sample","aria-hidden":"true",children:[u.jsx(Di,{size:28,strokeWidth:1.1}),u.jsx("span",{children:"Prévia do material"})]}),u.jsx("div",{className:"gw-presets","aria-label":"Predefinições",children:[{name:"Claro",value:{blur:8,opacity:.12,saturation:1.1,edge:.8}},{name:"Fosco",value:Te},{name:"Sólido",value:{blur:32,opacity:.86,saturation:1,edge:.35}}].map(x=>u.jsx("button",{type:"button",onClick:()=>Lt(x.value),children:x.name},x.name))}),[{key:"blur",label:"Desfoque",min:0,max:40,step:1,value:`${Math.round(M.blur)} px`},{key:"opacity",label:"Opacidade",min:.08,max:.9,step:.01,value:`${Math.round(M.opacity*100)}%`},{key:"saturation",label:"Saturação",min:.5,max:2,step:.05,value:`${Math.round(M.saturation*100)}%`},{key:"edge",label:"Brilho da borda",min:0,max:1,step:.05,value:`${Math.round(M.edge*100)}%`}].map(x=>u.jsxs("label",{className:"gw-range",children:[u.jsxs("span",{children:[x.label,u.jsx("output",{children:x.value})]}),u.jsx("input",{type:"range","aria-label":x.label,min:x.min,max:x.max,step:x.step,value:M[x.key],onChange:z=>Lt({[x.key]:Number(z.target.value)})})]},x.key)),u.jsxs("label",{className:"gw-tint",children:["Cor do vidro"," ",u.jsx("input",{type:"color",value:M.tint,onChange:x=>Lt({tint:x.target.value})})]}),u.jsx("button",{className:"gw-reset",type:"button",onClick:()=>Lt(Vt(f)),children:"Restaurar aparência"})]})]}),Ce&&u.jsxs("div",{className:"gw-toast",role:"status",children:[u.jsx(mr,{size:16,"aria-hidden":"true"}),Ce]})]})}const to=`
.gw-root {
  --gw-ink: var(--color-foreground, CanvasText);
  --gw-muted: var(--color-muted-foreground, GrayText);
  --gw-accent: var(--color-primary, Highlight);
  --gw-line: color-mix(
    in srgb,
    var(--color-border, CanvasText) 35%,
    transparent
  );
  --gw-background: var(--color-background, Canvas);
  --gw-shade: color-mix(
    in srgb,
    var(--color-background, Canvas) 22%,
    transparent
  );
  --gw-surface: var(--color-card, var(--color-background, Canvas));
  --gw-panel: var(--color-card, var(--color-background, Canvas));
  --gw-brand: var(--color-primary, Highlight);
  --gw-brand-ink: var(--color-primary-foreground, HighlightText);
  --gw-avatar: var(--color-secondary, ButtonFace);
  --gw-rail-active: color-mix(
    in srgb,
    var(--color-secondary, ButtonFace) 70%,
    transparent
  );
  --gw-positive-surface: color-mix(
    in srgb,
    var(--color-primary, Highlight) 15%,
    var(--color-card, Canvas)
  );
  --gw-account-surface: color-mix(
    in srgb,
    var(--color-secondary, ButtonFace) 45%,
    transparent
  );
  --gw-account-action: color-mix(
    in srgb,
    var(--color-secondary, ButtonFace) 45%,
    transparent
  );
  --gw-segment: color-mix(
    in srgb,
    var(--color-muted, ButtonFace) 25%,
    transparent
  );
  --gw-segment-active: color-mix(
    in srgb,
    var(--color-card, Canvas) 85%,
    transparent
  );
  --gw-transaction-surface: color-mix(
    in srgb,
    var(--color-secondary, ButtonFace) 45%,
    transparent
  );
  --gw-income-surface: color-mix(
    in srgb,
    var(--color-primary, Highlight) 15%,
    transparent
  );
  --gw-pending: var(--color-muted-foreground, GrayText);
  --gw-goal-surface: color-mix(
    in srgb,
    var(--color-secondary, ButtonFace) 40%,
    transparent
  );
  --gw-dock: color-mix(in srgb, var(--color-card, Canvas) 70%, transparent);
  --gw-dock-active: var(--color-secondary, ButtonFace);
  --gw-button: var(--color-primary, Highlight);
  --gw-button-ink: var(--color-primary-foreground, HighlightText);
  --gw-search: color-mix(in srgb, var(--color-input, Canvas) 35%, transparent);
  --gw-savings-orb: color-mix(
    in srgb,
    var(--color-primary, Highlight) 15%,
    transparent
  );
  --gw-popover: color-mix(
    in srgb,
    var(--color-popover, Canvas) 94%,
    transparent
  );
  --gw-notification: color-mix(
    in srgb,
    var(--color-popover, Canvas) 94%,
    transparent
  );
  --gw-fallback: var(--color-card, Canvas);
  --gw-mobile-dock: color-mix(
    in srgb,
    var(--color-card, Canvas) 55%,
    transparent
  );
  --gw-shadow: color-mix(
    in srgb,
    var(--color-foreground, CanvasText) 18%,
    transparent
  );
  --gw-panel-shadow: color-mix(
    in srgb,
    var(--color-foreground, CanvasText) 16%,
    transparent
  );
  --gw-soft-shadow: color-mix(
    in srgb,
    var(--color-foreground, CanvasText) 7%,
    transparent
  );
  --gw-segment-shadow: color-mix(
    in srgb,
    var(--color-foreground, CanvasText) 6%,
    transparent
  );
  --gw-dock-shadow: color-mix(
    in srgb,
    var(--color-foreground, CanvasText) 7%,
    transparent
  );
  --gw-popover-shadow: color-mix(
    in srgb,
    var(--color-foreground, CanvasText) 20%,
    transparent
  );
  --gw-sample-shadow: color-mix(
    in srgb,
    var(--color-foreground, CanvasText) 35%,
    transparent
  );
  --gw-toast-shadow: color-mix(
    in srgb,
    var(--color-foreground, CanvasText) 13%,
    transparent
  );
  --gw-toast: var(--color-primary, Highlight);
  --gw-dock-ink: var(--color-secondary-foreground, CanvasText);
  --gw-selection: color-mix(
    in srgb,
    var(--color-primary, Highlight) 35%,
    transparent
  );
  --gw-scrollbar: var(--color-muted-foreground, GrayText);
  --gw-hover: color-mix(
    in srgb,
    var(--color-secondary, ButtonFace) 25%,
    transparent
  );
  --gw-dock-hover: color-mix(
    in srgb,
    var(--color-secondary, ButtonFace) 30%,
    transparent
  );
  --gw-control-hover: color-mix(
    in srgb,
    var(--color-secondary, ButtonFace) 35%,
    transparent
  );
  --gw-strong-edge: color-mix(
    in srgb,
    var(--color-card, Canvas) 60%,
    transparent
  );
  --gw-soft-edge: color-mix(
    in srgb,
    var(--color-card, Canvas) 53%,
    transparent
  );
  --gw-toast-ink: var(--color-primary-foreground, HighlightText);
  --gw-highlight: var(--color-card, Canvas);
  position: relative;
  isolation: isolate;
  min-height: 100svh;
  overflow: hidden;
  padding: 38px 28px 32px;
  background: var(--gw-background);
  color: var(--gw-ink);
  font:
    14px/1.5 "Inter",
    system-ui,
    sans-serif;
  letter-spacing: -0.012em;
  font-variant-numeric: tabular-nums;
  box-sizing: border-box;
  color-scheme: inherit;
}
.gw-root[data-theme="light"] {
  color-scheme: light;
}
.gw-root[data-theme="dark"] {
  color-scheme: dark;
}
.gw-root * {
  box-sizing: border-box;
}
.gw-root ::selection {
  background: var(--gw-selection);
}
.gw-root button,
.gw-root input,
.gw-root a {
  font: inherit;
  color: inherit;
}
.gw-root button {
  cursor: pointer;
}
.gw-root button:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}
.gw-root button,
.gw-root a,
.gw-root input {
  outline-offset: 4px;
}
.gw-root :focus-visible {
  outline: 2px solid var(--gw-accent);
}
.gw-root button {
  border: 0;
  background: none;
}
.gw-root h1,
.gw-root h2,
.gw-root h3,
.gw-root p {
  margin: 0;
}
.gw-room {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center 56%;
  z-index: -3;
}
.gw-room-shade {
  position: absolute;
  inset: 0;
  background: var(--gw-shade);
  z-index: -2;
}
.gw-workspace {
  position: relative;
  width: min(1280px, 100%);
  margin: auto;
}
.gw-glass {
  background: color-mix(
    in srgb,
    var(--gw-surface) calc(var(--gw-opacity) * 100%),
    transparent
  );
  backdrop-filter: blur(var(--gw-blur)) saturate(var(--gw-saturation));
  -webkit-backdrop-filter: blur(var(--gw-blur)) saturate(var(--gw-saturation));
  box-shadow:
    inset 0 1px 0
      color-mix(
        in srgb,
        var(--gw-highlight) calc(var(--gw-edge) * 100%),
        transparent
      ),
    inset 0 0 0 1px
      color-mix(
        in srgb,
        var(--gw-highlight) calc(var(--gw-edge) * 34%),
        transparent
      ),
    0 20px 52px -25px var(--gw-shadow);
  position: relative;
}
.gw-glass:before {
  content: "";
  position: absolute;
  inset: 0;
  background: var(--gw-tint);
  opacity: 0.12;
  pointer-events: none;
  border-radius: inherit;
}
.gw-topbar {
  height: 62px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  border-radius: 20px;
  margin-bottom: 18px;
  padding: 0 20px;
}
.gw-brand {
  display: flex;
  align-items: center;
  gap: 10px;
  text-decoration: none;
  white-space: nowrap;
}
.gw-brand strong {
  font-size: 14px;
  letter-spacing: -0.025em;
}
.gw-brand-icon {
  display: grid;
  place-items: center;
  width: 29px;
  height: 29px;
  background: var(--gw-brand);
  color: var(--gw-brand-ink);
  border-radius: 9px;
}
.gw-brand-divider {
  height: 16px;
  width: 1px;
  background: var(--gw-line);
  margin: 0 4px;
}
.gw-personal {
  font-size: 12px;
  color: var(--gw-muted);
}
.gw-toolbar {
  display: flex;
  align-items: center;
  gap: 10px;
}
.gw-adjust {
  display: flex;
  align-items: center;
  gap: 8px;
  border-radius: 9px;
  padding: 8px 10px;
}
.gw-adjust:hover {
  background: var(--gw-hover);
}
.gw-icon-button {
  width: 34px;
  height: 34px;
  display: grid;
  place-items: center;
  border-radius: 50%;
  flex: none;
}
.gw-icon-button:hover {
  background: var(--gw-hover);
}
.gw-bell {
  position: relative;
}
.gw-bell i {
  position: absolute;
  right: 8px;
  top: 6px;
  background: var(--gw-accent);
  width: 4px;
  height: 4px;
  border-radius: 50%;
}
.gw-avatar {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background: var(--gw-avatar);
  display: grid;
  place-items: center;
  font:
    600 12px Georgia,
    serif;
}
.gw-stage {
  display: flex;
  gap: 16px;
  align-items: flex-start;
}
.gw-rail {
  border-radius: 23px;
  width: 50px;
  padding: 8px 5px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 50px;
  flex: none;
}
.gw-rail button {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: grid;
  place-items: center;
}
.gw-rail button span {
  display: none;
}
.gw-rail button[aria-current] {
  background: var(--gw-rail-active);
  box-shadow: 0 3px 8px var(--gw-soft-shadow);
}
.gw-main {
  border-radius: 27px;
  padding: 30px 30px 98px;
  flex: 1;
  min-width: 0;
}
.gw-view-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  margin-bottom: 28px;
}
.gw-greeting {
  font-size: 13px;
  color: var(--gw-muted);
  margin-bottom: 5px !important;
}
.gw-view-heading h1 {
  font-size: clamp(23px, 2.3vw, 31px);
  font-weight: 500;
  letter-spacing: -0.035em;
  line-height: 1.18;
}
.gw-date {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 12px;
  color: var(--gw-muted);
  white-space: nowrap;
}
.gw-panel {
  background: color-mix(
    in srgb,
    var(--gw-panel) calc((0.16 + var(--gw-opacity) * 0.5) * 100%),
    transparent
  );
  border-radius: 17px;
  box-shadow:
    inset 0 1px 0
      color-mix(
        in srgb,
        var(--gw-highlight) calc(var(--gw-edge) * 75%),
        transparent
      ),
    0 8px 22px -20px var(--gw-panel-shadow);
  padding: 21px;
  min-width: 0;
  position: relative;
}
.gw-panel-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 20px;
  color: var(--gw-muted);
  font-size: 12px;
}
.gw-panel-title h2 {
  font-size: 14px;
  letter-spacing: -0.02em;
  font-weight: 600;
  color: var(--gw-ink);
}
.gw-panel-title > svg {
  opacity: 0.65;
}
.gw-overview-grid {
  display: grid;
  grid-template-columns: 0.82fr 1.5fr;
  gap: 16px;
  margin-bottom: 16px;
}
.gw-balance {
  display: flex;
  flex-direction: column;
}
.gw-balance-value {
  font-size: clamp(29px, 3.15vw, 43px);
  font-weight: 500;
  letter-spacing: -0.04em;
  line-height: 1.25;
  white-space: nowrap;
}
.gw-balance-meta {
  font-size: 11px;
  color: var(--gw-muted);
  margin-top: 10px !important;
}
.gw-positive {
  color: var(--gw-accent);
}
.gw-balance-meta .gw-positive {
  background: var(--gw-positive-surface);
  border-radius: 5px;
  padding: 3px 5px;
  margin-right: 5px;
}
.gw-account {
  margin-top: auto;
  padding-top: 35px;
  display: flex;
  align-items: center;
  gap: 10px;
}
.gw-account-icon {
  display: grid;
  place-items: center;
  width: 36px;
  height: 36px;
  border-radius: 10px;
  background: var(--gw-account-surface);
}
.gw-account > div {
  display: flex;
  flex-direction: column;
}
.gw-account strong {
  font-weight: 500;
  font-size: 12px;
}
.gw-account span {
  font-size: 11px;
  color: var(--gw-muted);
}
.gw-account > button {
  margin-left: auto;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: var(--gw-account-action);
  display: grid;
  place-items: center;
}
.gw-segment {
  display: flex;
  gap: 3px;
  background: var(--gw-segment);
  border-radius: 8px;
  padding: 3px;
  font-size: 10px;
}
.gw-segment button {
  padding: 4px 8px;
  border-radius: 6px;
}
.gw-segment button[aria-pressed="true"] {
  background: var(--gw-segment-active);
  box-shadow: 0 2px 4px var(--gw-segment-shadow);
  color: var(--gw-ink);
}
.gw-chart-summary {
  display: flex;
  gap: 34px;
  margin-bottom: 18px;
}
.gw-chart-legend {
  display: flex;
  gap: 20px;
  margin: -4px 0 14px;
  font-size: 11px;
  color: var(--gw-muted);
}
.gw-chart-legend span {
  display: flex;
  gap: 6px;
  align-items: center;
}
.gw-chart-legend i {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--gw-accent);
}
.gw-chart-legend span + span i {
  background: var(--gw-muted);
}
.gw-chart-summary > div {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.gw-chart-summary span {
  font-size: 10px;
  color: var(--gw-muted);
  display: flex;
  align-items: center;
  gap: 5px;
}
.gw-chart-summary i {
  width: 5px;
  height: 5px;
  background: var(--gw-accent);
  border-radius: 50%;
}
.gw-chart-summary > div + div i {
  background: var(--gw-muted);
}
.gw-chart-summary strong {
  font-size: 21px;
  font-weight: 500;
  letter-spacing: -0.03em;
}
.gw-chart-wrap {
  position: relative;
  padding-left: 39px;
  padding-top: 2px;
}
.gw-chart-wrap svg {
  display: block;
  width: 100%;
  height: 126px;
  overflow: visible;
}
.gw-chart-labels {
  position: absolute;
  left: 0;
  top: 6px;
  bottom: 22px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  font-size: 8px;
  color: var(--gw-muted);
}
.gw-chart-months {
  position: relative;
  height: 24px;
  font-size: 9px;
  color: var(--gw-muted);
  padding-top: 10px;
}
.gw-lower-grid {
  display: grid;
  grid-template-columns: 1.3fr 1fr;
  gap: 16px;
}
.gw-text-button {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 11px !important;
}
.gw-text-button:hover {
  color: var(--gw-accent);
}
.gw-transaction {
  display: flex;
  align-items: center;
  gap: 11px;
  padding: 11px 0;
  border-top: 1px solid var(--gw-line);
  min-width: 0;
}
.gw-transaction:first-child {
  border-top: 0;
  padding-top: 0;
}
.gw-transaction:last-child {
  padding-bottom: 0;
}
.gw-transaction-icon {
  width: 34px;
  height: 34px;
  border-radius: 10px;
  display: grid;
  place-items: center;
  background: var(--gw-transaction-surface);
  flex: none;
}
.gw-transaction-icon.is-income {
  background: var(--gw-income-surface);
  color: var(--gw-accent);
}
.gw-transaction-name {
  display: flex;
  flex-direction: column;
  min-width: 0;
  flex: 1;
}
.gw-transaction-name strong {
  font-size: 12px;
  font-weight: 500;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.gw-transaction-name span {
  font-size: 10px;
  color: var(--gw-muted);
  margin-top: 2px;
}
.gw-transaction > strong {
  font-size: 12px;
  font-weight: 500;
  white-space: nowrap;
}
.gw-transaction-status {
  font-size: 9px;
  color: var(--gw-muted);
  display: flex;
  align-items: center;
  gap: 3px;
}
.gw-transaction-status.is-pending {
  color: var(--gw-pending);
}
.gw-small-label {
  font-size: 10px;
}
.gw-goal + .gw-goal {
  margin-top: 22px;
}
.gw-goal-top {
  display: flex;
  align-items: center;
  gap: 9px;
}
.gw-goal-top strong {
  font-size: 12px;
  font-weight: 500;
  flex: 1;
}
.gw-goal-top > span:last-child {
  font-size: 10px;
  color: var(--gw-muted);
}
.gw-goal-icon {
  width: 30px;
  height: 30px;
  border-radius: 9px;
  background: var(--gw-goal-surface);
  display: grid;
  place-items: center;
}
.gw-goal-track {
  height: 5px;
  background: var(--gw-line);
  margin: 11px 0 6px;
  border-radius: 5px;
  overflow: hidden;
}
.gw-goal-track i {
  height: 100%;
  display: block;
  background: var(--gw-accent);
  border-radius: 5px;
}
.gw-goal p {
  display: flex;
  justify-content: space-between;
  font-size: 10px;
  color: var(--gw-muted);
}
.gw-goal p strong {
  font-weight: 500;
  color: var(--gw-ink);
}
.gw-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  color: var(--gw-muted);
  font-size: 9px;
  margin-top: 22px;
  gap: 16px;
}
.gw-footer > span:first-child {
  display: flex;
  align-items: center;
  gap: 6px;
}
.gw-footer i {
  height: 4px;
  width: 4px;
  background: var(--gw-accent);
  border-radius: 50%;
}
.gw-desktop-dock {
  position: absolute;
  bottom: 19px;
  left: 50%;
  transform: translateX(-50%);
}
.gw-dock {
  display: flex;
  align-items: center;
  gap: 3px;
  border-radius: 30px;
  padding: 5px;
  white-space: nowrap;
  background: var(--gw-dock);
  backdrop-filter: blur(20px);
}
.gw-dock button {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  border-radius: 24px;
  padding: 10px 17px;
  font-size: 11px;
  transition:
    background 0.22s,
    color 0.22s;
}
.gw-dock button svg {
  width: 15px;
}
.gw-dock button[aria-current] {
  background: var(--gw-dock-active);
  color: var(--gw-dock-ink);
  box-shadow: 0 3px 7px var(--gw-dock-shadow);
}
.gw-dock button:not([aria-current]):hover {
  background: var(--gw-dock-hover);
}
.gw-mobile-nav {
  display: none;
}
.gw-button {
  padding: 9px 13px;
  border-radius: 9px;
  display: flex;
  align-items: center;
  gap: 7px;
  background: var(--gw-button) !important;
  color: var(--gw-button-ink) !important;
  font-size: 11px !important;
  white-space: nowrap;
}
.gw-button:hover {
  filter: brightness(1.13);
}
.gw-search {
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--gw-search);
  border: 1px solid var(--gw-line);
  border-radius: 8px;
  padding: 7px 10px;
}
.gw-search input {
  width: 165px;
  background: none;
  border: 0;
  caret-color: var(--gw-accent);
  font-size: 11px;
}
.gw-search input::placeholder {
  color: var(--gw-muted);
}
.gw-search button {
  padding: 0;
  display: flex;
}
.gw-count {
  margin-left: 6px;
  font-size: 10px;
  color: var(--gw-muted);
}
.gw-empty {
  text-align: center;
  padding: 70px 15px;
  color: var(--gw-muted);
  font-size: 12px;
}
.gw-empty svg {
  margin-bottom: 12px;
}
.gw-empty h3 {
  font-size: 15px;
  color: var(--gw-ink);
  margin-bottom: 6px;
}
.gw-empty button {
  margin-top: 15px;
  text-decoration: underline;
}
.gw-savings-intro {
  display: flex;
  align-items: center;
  gap: 20px;
  padding: 20px 10px 35px;
}
.gw-savings-orb {
  width: 65px;
  height: 65px;
  display: grid;
  place-items: center;
  border-radius: 50%;
  background: var(--gw-savings-orb);
  box-shadow: inset 0 1px 0 var(--gw-strong-edge);
}
.gw-savings-intro p {
  font-size: 12px;
  color: var(--gw-muted);
}
.gw-savings-intro strong {
  font-size: 40px;
  letter-spacing: -0.04em;
  font-weight: 500;
}
.gw-savings-intro > span:last-child {
  margin-left: auto;
  font-size: 13px;
  color: var(--gw-muted);
}
.gw-view:has(.gw-savings-intro) .gw-goals {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 34px;
}
.gw-view:has(.gw-savings-intro) .gw-goal + .gw-goal {
  margin-top: 0;
}
.gw-savings-note {
  display: flex;
  align-items: center;
  gap: 12px;
  color: var(--gw-muted);
  font-size: 12px;
  padding: 24px 4px;
}
.gw-report-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
  margin-bottom: 16px;
}
.gw-report-stats strong {
  font-size: 28px;
  font-weight: 500;
  letter-spacing: -0.035em;
  display: block;
}
.gw-report-stats section > span {
  font-size: 10px;
  color: var(--gw-muted);
}
.gw-report-stats .gw-panel-title {
  margin-bottom: 15px;
}
.gw-reports-grid {
  display: grid;
  grid-template-columns: 1.6fr 1fr;
  gap: 16px;
}
.gw-reports-grid .gw-chart-wrap svg {
  height: 185px;
}
.gw-chart-footnote {
  font-size: 9px;
  color: var(--gw-muted);
  margin-top: 15px !important;
}
.gw-category-list > div + div {
  margin-top: 19px;
}
.gw-category-list > div > div {
  display: flex;
  gap: 7px;
  align-items: center;
  font-size: 11px;
}
.gw-category-list strong {
  margin-left: auto;
  font-weight: 500;
}
.gw-category-list svg {
  width: 14px;
}
.gw-category-track {
  display: block;
  height: 4px;
  border-radius: 3px;
  background: var(--gw-line);
  margin-top: 9px;
}
.gw-category-track i {
  display: block;
  height: 100%;
  background: var(--gw-accent);
  border-radius: 3px;
}
.gw-material {
  position: absolute;
  z-index: 20;
  max-height: calc(100svh - 128px);
  overflow: auto;
  scrollbar-width: thin;
  scrollbar-color: var(--gw-scrollbar) transparent;
  right: 10px;
  top: 75px;
  width: 300px;
  border-radius: 22px;
  padding: 22px;
  background: var(--gw-popover);
  box-shadow:
    inset 0 1px 0 var(--gw-soft-edge),
    0 24px 80px var(--gw-popover-shadow);
}
.gw-material-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.gw-material-title > div {
  display: flex;
  gap: 10px;
  align-items: center;
}
.gw-material h2 {
  font-size: 17px;
  font-weight: 500;
  letter-spacing: -0.03em;
}
.gw-material-icon {
  display: grid;
  place-items: center;
}
.gw-material > p {
  font-size: 11px;
  color: var(--gw-muted);
  margin: 7px 0 18px;
}
.gw-material-sample {
  height: 87px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  border-radius: 13px;
  margin-bottom: 17px;
  background: color-mix(
    in srgb,
    var(--gw-tint) calc(var(--gw-opacity) * 100%),
    transparent
  );
  backdrop-filter: blur(var(--gw-blur));
  box-shadow:
    inset 0 1px 0
      color-mix(
        in srgb,
        var(--gw-highlight) calc(var(--gw-edge) * 100%),
        transparent
      ),
    0 12px 20px -18px var(--gw-sample-shadow);
  font-size: 12px;
}
.gw-presets {
  display: flex;
  gap: 5px;
  margin-bottom: 20px;
}
.gw-presets button {
  flex: 1;
  border: 1px solid var(--gw-line);
  border-radius: 7px;
  padding: 6px 0;
  font-size: 11px;
}
.gw-presets button:hover {
  background: var(--gw-control-hover);
}
.gw-range {
  display: block;
  margin: 17px 0;
}
.gw-range > span {
  display: flex;
  justify-content: space-between;
  font-size: 11px;
}
.gw-range output {
  font-size: 10px;
  color: var(--gw-muted);
}
.gw-range input {
  width: 100%;
  accent-color: var(--gw-accent);
  height: 16px;
  margin: 8px 0 0;
  cursor: pointer;
}
.gw-tint {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11px;
  margin-top: 20px;
}
.gw-tint input {
  height: 28px;
  width: 42px;
  padding: 2px;
  background: none;
  border: 1px solid var(--gw-line);
  border-radius: 6px;
  cursor: pointer;
}
.gw-reset {
  width: 100%;
  border: 1px solid var(--gw-line) !important;
  border-radius: 8px;
  padding: 8px;
  margin-top: 22px;
  font-size: 11px !important;
}
.gw-reset:hover {
  background: var(--gw-control-hover);
}
.gw-notifications {
  position: absolute;
  right: 25px;
  top: 75px;
  z-index: 21;
  width: 280px;
  border-radius: 16px;
  padding: 22px;
  background: var(--gw-notification);
}
.gw-notifications > div {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.gw-notifications h2 {
  font-size: 15px;
  font-weight: 500;
}
.gw-notifications p {
  margin-top: 8px;
  font-size: 12px;
  color: var(--gw-muted);
}
.gw-toast {
  position: fixed;
  left: 50%;
  bottom: 25px;
  transform: translateX(-50%);
  z-index: 30;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 13px 20px;
  border-radius: 12px;
  background: var(--gw-toast);
  color: var(--gw-toast-ink);
  box-shadow: 0 10px 30px var(--gw-toast-shadow);
  font-size: 12px;
  white-space: nowrap;
}
.gw-sun {
  display: none;
}
[data-theme="dark"] .gw-sun {
  display: block;
}
[data-theme="dark"] .gw-moon {
  display: none;
}
.gw-chart-months > span {
  position: absolute;
  white-space: nowrap;
}
.gw-chart-empty {
  padding: 35px 15px;
  min-height: 160px;
}
@supports not (backdrop-filter: blur(1px)) {
  .gw-glass,
  .gw-panel {
    background: var(--gw-fallback);
  }
}
@media (min-width: 1550px) {
  .gw-root {
    padding-top: 65px;
  }
  .gw-main {
    padding-top: 36px;
  }
  .gw-chart-wrap svg {
    height: 150px;
  }
  .gw-panel {
    padding: 25px;
  }
  .gw-transaction {
    padding: 14px 0;
  }
}
@media (max-width: 1050px) {
  .gw-root {
    padding: 24px 18px;
  }
  .gw-main {
    padding: 25px 23px 92px;
  }
  .gw-rail {
    display: none;
  }
  .gw-balance-value {
    font-size: 32px;
  }
  .gw-transaction-status {
    display: none;
  }
  .gw-personal,
  .gw-brand-divider {
    display: none;
  }
  .gw-panel {
    padding: 18px;
  }
  .gw-chart-summary {
    gap: 20px;
  }
  .gw-chart-summary strong {
    font-size: 19px;
  }
}
@media (max-width: 700px) {
  .gw-root {
    padding: 12px 10px 24px;
  }
  .gw-topbar {
    height: 56px;
    padding: 0 12px;
    border-radius: 17px;
    margin-bottom: 12px;
  }
  .gw-toolbar {
    gap: 3px;
  }
  .gw-brand {
    gap: 7px;
  }
  .gw-brand strong {
    font-size: 12px;
  }
  .gw-brand-icon {
    width: 25px;
    height: 25px;
  }
  .gw-bell,
  .gw-avatar {
    display: none !important;
  }
  .gw-adjust {
    padding: 8px;
    font-size: 11px !important;
    gap: 5px;
  }
  .gw-main {
    border-radius: 20px;
    padding: 23px 15px;
  }
  .gw-view-heading {
    gap: 8px;
    align-items: flex-start;
    margin-bottom: 20px;
  }
  .gw-view-heading h1 {
    font-size: 25px;
    max-width: 290px;
    line-height: 1.12;
  }
  .gw-greeting {
    font-size: 11px;
  }
  .gw-heading-action .gw-date {
    display: none;
  }
  .gw-heading-action .gw-button {
    padding: 8px 10px;
    font-size: 10px !important;
  }
  .gw-mobile-nav {
    display: block;
    margin-bottom: 20px;
  }
  .gw-mobile-nav .gw-dock {
    width: 100%;
    padding: 4px;
    border-radius: 12px;
    justify-content: space-between;
    background: var(--gw-mobile-dock);
    box-shadow: none;
  }
  .gw-dock button {
    font-size: 10px;
    padding: 9px 10px;
    border-radius: 9px;
    gap: 5px;
  }
  .gw-dock button svg {
    width: 13px;
    height: 13px;
  }
  .gw-desktop-dock {
    display: none;
  }
  .gw-overview-grid,
  .gw-lower-grid,
  .gw-reports-grid {
    grid-template-columns: 1fr;
    gap: 12px;
  }
  .gw-overview-grid {
    margin-bottom: 12px;
  }
  .gw-balance {
    min-height: 221px;
  }
  .gw-balance-value {
    font-size: 39px;
  }
  .gw-balance-meta {
    font-size: 11px;
  }
  .gw-account {
    padding-top: 23px;
  }
  .gw-panel {
    border-radius: 15px;
    padding: 18px;
  }
  .gw-chart-wrap svg {
    height: 130px;
  }
  .gw-chart-summary strong {
    font-size: 22px;
  }
  .gw-chart-summary {
    gap: 35px;
  }
  .gw-panel-title {
    gap: 8px;
    margin-bottom: 18px;
  }
  .gw-footer {
    font-size: 8px;
    margin-top: 24px;
  }
  .gw-footer > span:last-child {
    display: none;
  }
  .gw-material {
    right: 4px;
    top: 65px;
    width: min(310px, calc(100% - 8px));
    padding: 20px;
    max-height: calc(100svh - 90px);
    overflow: auto;
    scrollbar-width: thin;
    scrollbar-color: var(--gw-scrollbar) transparent;
  }
  .gw-notifications {
    right: 4px;
    max-width: calc(100% - 8px);
  }
  .gw-transaction-name strong,
  .gw-transaction > strong {
    font-size: 11px;
  }
  .gw-search {
    padding: 7px;
    width: 100%;
  }
  .gw-search input {
    width: 100%;
    min-width: 0;
  }
  .gw-view:has(.gw-search) .gw-panel-title {
    flex-wrap: wrap;
  }
  .gw-report-stats {
    grid-template-columns: 1fr;
    gap: 12px;
    margin-bottom: 12px;
  }
  .gw-report-stats .gw-panel {
    display: grid;
    grid-template-columns: 1fr auto;
    align-items: center;
  }
  .gw-report-stats .gw-panel-title {
    margin: 0;
  }
  .gw-report-stats .gw-panel-title svg {
    display: none;
  }
  .gw-report-stats strong {
    font-size: 26px;
  }
  .gw-report-stats section > span {
    grid-column: 1/-1;
    margin-top: 8px;
  }
  .gw-savings-intro {
    gap: 12px;
    padding: 10px 2px 26px;
    flex-wrap: wrap;
  }
  .gw-savings-intro strong {
    font-size: 34px;
  }
  .gw-savings-intro > span:last-child {
    display: none;
  }
  .gw-savings-orb {
    width: 52px;
    height: 52px;
  }
  .gw-view:has(.gw-savings-intro) .gw-goals {
    grid-template-columns: 1fr;
    gap: 25px;
  }
  .gw-view:has(.gw-search) {
    min-height: 370px;
  }
  .gw-toast {
    max-width: calc(100% - 30px);
    font-size: 11px;
    white-space: normal;
  }
  .gw-chart-months {
    font-size: 8px;
  }
}
@media (max-height: 550px) {
  .gw-material {
    top: 70px;
    max-height: calc(100svh - 110px);
  }
}
@media (prefers-reduced-motion: reduce) {
  .gw-root * {
    scroll-behavior: auto !important;
    transition: none !important;
  }
}
`,ro={"--gw-ink":"#f3f6fa","--gw-muted":"#a7b3c4","--gw-accent":"#20d66b","--gw-line":"#ffffff1f","--gw-background":"radial-gradient(45% 55% at 85% 10%, #20d66b40, transparent 70%), radial-gradient(40% 50% at 5% 95%, #20d66b26, transparent 70%), radial-gradient(60% 60% at 40% 40%, #163a66, transparent 75%), #050e1c","--gw-shade":"#00000000","--gw-surface":"#0b1d35","--gw-panel":"#0b1d35","--gw-brand":"#20d66b","--gw-brand-ink":"#081629","--gw-avatar":"#112849","--gw-rail-active":"#20d66b26","--gw-positive-surface":"#20d66b26","--gw-account-surface":"#ffffff12","--gw-account-action":"#ffffff14","--gw-segment":"#ffffff10","--gw-segment-active":"#ffffff26","--gw-transaction-surface":"#ffffff10","--gw-income-surface":"#20d66b22","--gw-pending":"#f2c86b","--gw-goal-surface":"#ffffff12","--gw-dock":"#081629cc","--gw-dock-active":"#20d66b","--gw-dock-ink":"#081629","--gw-button":"#20d66b","--gw-button-ink":"#081629","--gw-search":"#05101e88","--gw-savings-orb":"#20d66b22","--gw-popover":"#0b1d35f2","--gw-notification":"#0b1d35f2","--gw-fallback":"#0b1d35","--gw-mobile-dock":"#08162999","--gw-shadow":"#00000080","--gw-panel-shadow":"#00000066","--gw-soft-shadow":"#00000033","--gw-segment-shadow":"#00000033","--gw-dock-shadow":"#00000040","--gw-popover-shadow":"#00000080","--gw-sample-shadow":"#00000080","--gw-toast-shadow":"#00000060","--gw-toast":"#20d66b","--gw-toast-ink":"#081629","--gw-selection":"#20d66b55","--gw-scrollbar":"#7c8aa0","--gw-hover":"#ffffff14","--gw-dock-hover":"#ffffff18","--gw-control-hover":"#ffffff1c","--gw-strong-edge":"#ffffff40","--gw-soft-edge":"#ffffff26","--gw-highlight":"#ffffff",minHeight:"calc(100svh - 52px)"},io={blur:22,opacity:.42,saturation:1.2,edge:.28,tint:"#0b1d35"},no=[{id:"1",name:"Comissão — venda apartamento",category:"Receita",date:"Hoje",amount:9400,status:"Completed"},{id:"2",name:"Anúncios em portais",category:"Marketing",date:"Hoje",amount:-620,status:"Completed"},{id:"3",name:"Visita a lançamento",category:"Viagem",date:"Ontem",amount:-180,status:"Completed"},{id:"4",name:"Comissão — locação",category:"Receita",date:"05 nov",amount:2100,status:"Pending"},{id:"5",name:"Fotos profissionais do imóvel",category:"Marketing",date:"04 nov",amount:-450,status:"Completed"},{id:"6",name:"Café com cliente",category:"Alimentação",date:"03 nov",amount:-48,status:"Completed"},{id:"7",name:"Ferramentas e CRM",category:"Operação",date:"01 nov",amount:-290,status:"Completed"}],so=[{id:"vendas",name:"Meta de vendas do trimestre",saved:31500,target:6e4},{id:"reserva",name:"Reserva para marketing",saved:4200,target:8e3}],ao=[{id:"week",label:"Semana",description:"Valores ilustrativos por dia da semana.",points:[{label:"Seg",income:0,expenses:210},{label:"Ter",income:2100,expenses:450},{label:"Qua",income:0,expenses:120},{label:"Qui",income:0,expenses:290},{label:"Sex",income:9400,expenses:620},{label:"Sáb",income:0,expenses:180},{label:"Dom",income:0,expenses:48}]},{id:"month",label:"Mês",description:"Valores ilustrativos agrupados por período do mês.",points:[{label:"01 nov",income:1200,expenses:380},{label:"05 nov",income:2100,expenses:520},{label:"10 nov",income:0,expenses:340},{label:"15 nov",income:4800,expenses:610},{label:"20 nov",income:1500,expenses:290},{label:"25 nov",income:9400,expenses:700},{label:"30 nov",income:3200,expenses:450}]},{id:"year",label:"Ano",description:"Valores ilustrativos mensais.",points:["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"].map((o,e)=>({label:o,income:[8200,9100,7400,11800,10200,12600,9800,14100,13200,15400,22200,18e3][e],expenses:[2600,2900,2400,3300,3100,3600,3e3,3900,3700,4100,3290,4400][e]}))}];function oo(){return u.jsxs(u.Fragment,{children:[u.jsxs("div",{className:"demo-bar",children:[u.jsx("a",{href:"./index.html",className:"demo-bar__back",children:"← Voltar ao site"}),u.jsx("span",{className:"demo-bar__label",children:"Demonstração · dados ilustrativos"})]}),u.jsx(eo,{brand:us.name,balance:18640,balanceChange:{percent:12.4,label:"em relação ao mês anterior (ilustrativo)"},account:{name:"Conta comercial",lastFour:"0000"},periodLabel:"Novembro 2026",cashFlowPeriods:ao,initialPeriodId:"month",footerNote:"Todos os valores são ilustrativos — painel de demonstração",savingsNote:"O progresso exibido vem de metas fictícias usadas apenas para demonstração.",transactions:no,goals:so,glass:io,currency:"BRL",theme:"dark",useHostTheme:!1,style:ro})]})}hs.createRoot(document.getElementById("root")).render(u.jsx(ps.StrictMode,{children:u.jsx(oo,{})}));
